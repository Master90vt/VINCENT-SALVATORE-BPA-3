# 🤝 Contributing to Business Productivity Analyzer

First off, thank you for considering contributing to the Business Productivity Analyzer! It's people like you that make this tool better for everyone.

## 📋 Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
- [Development Setup](#development-setup)
- [Coding Standards](#coding-standards)
- [Commit Guidelines](#commit-guidelines)
- [Pull Request Process](#pull-request-process)
- [Testing](#testing)
- [Documentation](#documentation)

---

## 📜 Code of Conduct

This project and everyone participating in it is governed by our commitment to creating a welcoming and inclusive environment. By participating, you are expected to uphold this standard.

**Our Standards:**
- Use welcoming and inclusive language
- Be respectful of differing viewpoints and experiences
- Gracefully accept constructive criticism
- Focus on what is best for the community
- Show empathy towards other community members

---

## 🎯 How Can I Contribute?

### Reporting Bugs

Before creating bug reports, please check existing issues to avoid duplicates. When creating a bug report, include as many details as possible:

**Bug Report Template:**
```markdown
**Browser & Version:** Chrome 118 / Firefox 119 / Safari 16

**Steps to Reproduce:**
1. Go to '...'
2. Click on '...'
3. Enter data '...'
4. See error

**Expected Behavior:**
A clear description of what you expected to happen.

**Actual Behavior:**
What actually happened.

**Screenshots:**
If applicable, add screenshots to help explain your problem.

**Additional Context:**
Any other context about the problem.
```

### Suggesting Enhancements

Enhancement suggestions are tracked as GitHub issues. When creating an enhancement suggestion, include:

**Enhancement Template:**
```markdown
**Feature Description:**
Clear description of the feature you'd like to see.

**Use Case:**
Explain why this feature would be useful.

**Proposed Solution:**
How you think this should work.

**Alternatives Considered:**
Any alternative solutions you've thought about.

**Additional Context:**
Mockups, examples, or references.
```

### Your First Code Contribution

Unsure where to begin? Look for issues labeled:
- `good first issue` - Good for newcomers
- `help wanted` - Need community help
- `documentation` - Improve docs
- `bug` - Fix bugs

---

## 🛠️ Development Setup

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Text editor (VS Code, Sublime, Atom, etc.)
- Basic understanding of HTML, CSS, JavaScript

### Getting Started

1. **Fork the repository**
   ```bash
   # Click "Fork" button on GitHub
   ```

2. **Clone your fork**
   ```bash
   git clone https://github.com/YOUR-USERNAME/business-productivity-analyzer.git
   cd business-productivity-analyzer
   ```

3. **Create a branch**
   ```bash
   git checkout -b feature/your-feature-name
   # or
   git checkout -b fix/bug-description
   ```

4. **Start a local server**
   ```bash
   # Option 1: Python
   python -m http.server 8000
   
   # Option 2: Node.js
   npx http-server -p 8000
   
   # Option 3: VS Code Live Server extension
   # Right-click index.html → "Open with Live Server"
   ```

5. **Open in browser**
   ```
   http://localhost:8000
   ```

---

## 📝 Coding Standards

### JavaScript

**Style Guide:**
- Use ES6+ features (const, let, arrow functions, template literals)
- 4-space indentation
- Semicolons required
- Single quotes for strings
- Descriptive variable names (camelCase)
- Functions should do one thing well
- Add JSDoc comments for complex functions

**Example:**
```javascript
/**
 * Calculate revenue per hour for a company
 * @param {number} revenue - Total revenue
 * @param {number} hours - Total hours worked
 * @returns {number} Revenue per hour
 */
function calculateRPH(revenue, hours) {
    if (hours <= 0) {
        console.error('Hours must be greater than 0');
        return 0;
    }
    return revenue / hours;
}
```

### HTML

- Use semantic HTML5 elements
- Proper indentation (4 spaces)
- Descriptive class names
- Accessibility attributes (alt, aria-label, etc.)
- Mobile-first responsive design

### CSS / Tailwind

- Use Tailwind utility classes
- Follow mobile-first approach
- Use dark mode variants where applicable
- Custom CSS only when necessary
- Group related utilities together

**Example:**
```html
<div class="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 mb-4">
    <!-- Content -->
</div>
```

---

## 💬 Commit Guidelines

We follow the [Conventional Commits](https://www.conventionalcommits.org/) specification.

### Commit Message Format

```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types

- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, etc.)
- `refactor`: Code refactoring
- `perf`: Performance improvements
- `test`: Adding tests
- `chore`: Maintenance tasks

### Examples

```bash
# Good commits
feat(calculator): add GVA per hour calculation
fix(charts): correct radar chart color in dark mode
docs(readme): add installation instructions
style(app): improve button spacing and alignment
refactor(insights): simplify winner determination logic
perf(charts): optimize chart re-rendering performance

# Bad commits (too vague)
fix: bug fix
update: changes
misc: stuff
```

### Commit Best Practices

- Keep commits atomic (one logical change per commit)
- Write clear, descriptive commit messages
- Reference issue numbers when applicable
- Keep the subject line under 50 characters
- Use imperative mood ("add" not "added" or "adds")

---

## 🔄 Pull Request Process

### Before Submitting

1. **Test your changes thoroughly**
   - Test in multiple browsers (Chrome, Firefox, Safari)
   - Test responsive design (mobile, tablet, desktop)
   - Test dark/light mode
   - Test with example data
   - Test edge cases

2. **Update documentation**
   - Update README.md if needed
   - Update CHANGELOG.md
   - Add code comments
   - Update EXAMPLES.md if adding features

3. **Follow coding standards**
   - Consistent formatting
   - No console.log() in production code
   - Meaningful variable names
   - Proper error handling

### Submitting Pull Request

1. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```

2. **Create Pull Request**
   - Go to original repository
   - Click "New Pull Request"
   - Select your branch
   - Fill in the template

### Pull Request Template

```markdown
## Description
Brief description of what this PR does.

## Type of Change
- [ ] Bug fix (non-breaking change which fixes an issue)
- [ ] New feature (non-breaking change which adds functionality)
- [ ] Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] Documentation update

## How Has This Been Tested?
- [ ] Chrome
- [ ] Firefox
- [ ] Safari
- [ ] Edge
- [ ] Mobile devices

## Checklist
- [ ] My code follows the style guidelines of this project
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings
- [ ] I have tested my changes thoroughly
- [ ] Any dependent changes have been merged and published

## Screenshots (if applicable)
Add screenshots to help explain your changes.

## Additional Notes
Any additional information.
```

### After Submission

- Be responsive to feedback
- Make requested changes promptly
- Keep the PR focused and manageable
- Don't force push after review starts

---

## 🧪 Testing

### Manual Testing Checklist

**Core Functionality:**
- [ ] Input validation works correctly
- [ ] All metrics calculate accurately
- [ ] CPI calculates and updates with weight changes
- [ ] Charts render correctly
- [ ] Insights generate appropriately
- [ ] Recommendations are relevant

**Browser Compatibility:**
- [ ] Chrome (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)
- [ ] Edge (latest)
- [ ] Mobile browsers

**Responsive Design:**
- [ ] Mobile (320px - 640px)
- [ ] Tablet (641px - 1024px)
- [ ] Desktop (1025px+)

**Dark Mode:**
- [ ] All elements visible in dark mode
- [ ] Charts render with correct colors
- [ ] Text contrast is sufficient

**Edge Cases:**
- [ ] Zero profit
- [ ] Very high margins (>80%)
- [ ] Extreme hours per employee
- [ ] Missing COGS data
- [ ] Negative profit

**Export Features:**
- [ ] CSV export works
- [ ] Print to PDF works
- [ ] HTML report downloads
- [ ] Copy to clipboard works

### Test Data

Use the examples from `EXAMPLES.md` for testing:
- Scenario 1: Traditional Retail vs E-commerce
- Scenario 2: Agency vs Freelancer
- All edge cases

---

## 📚 Documentation

### What to Document

**Code Documentation:**
- Complex algorithms or calculations
- Non-obvious business logic
- Function parameters and return values
- Important state changes
- Edge cases handling

**User Documentation:**
- New features in README.md
- Usage examples in EXAMPLES.md
- Breaking changes in CHANGELOG.md
- Configuration options

### Documentation Style

- Clear and concise
- Use examples
- Explain the "why" not just the "what"
- Keep it updated with code changes
- Use proper markdown formatting

---

## 🎨 Design Decisions

When proposing UI/UX changes, consider:
- **Consistency** - Match existing design patterns
- **Accessibility** - WCAG AA compliance
- **Responsive** - Works on all screen sizes
- **Performance** - Fast and efficient
- **User-friendly** - Intuitive and clear

---

## 🚀 Release Process

1. Update version in `package.json`
2. Update `CHANGELOG.md` with changes
3. Create release branch
4. Test thoroughly
5. Merge to main
6. Create GitHub release with notes
7. Tag the release

---

## 📞 Questions?

- Check existing documentation (README, EXAMPLES)
- Search existing issues
- Create a new issue with the "question" label
- Reach out to maintainers

---

## 🙏 Recognition

Contributors will be recognized in:
- GitHub contributors page
- README.md acknowledgments section
- Release notes

---

**Thank you for contributing to Business Productivity Analyzer!** 🎉

Your contributions help businesses worldwide improve their productivity and make better data-driven decisions.

---

*Last Updated: 2024-10-27*
