#!/bin/bash

###############################################################################
# VINCENT SALVATORE Business Productivity Analyzer
# Script Automatico Deploy su GitHub
###############################################################################

echo "🚀 VINCENT SALVATORE BPA - Deploy Script"
echo "=========================================="
echo ""

# Colori per output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funzione per stampare messaggi colorati
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# Verifica che Git sia installato
if ! command -v git &> /dev/null; then
    print_error "Git non è installato. Installalo da: https://git-scm.com"
    exit 1
fi

print_success "Git è installato"
echo ""

# Chiedi informazioni all'utente
echo "📝 Configurazione Deploy"
echo "========================"
echo ""

read -p "GitHub Username: " github_username
read -p "Nome Repository (es: vincent-salvatore-bpa): " repo_name
read -p "Email GitHub: " github_email

echo ""
print_info "Configurazione:"
echo "  Username: $github_username"
echo "  Repository: $repo_name"
echo "  Email: $github_email"
echo ""

read -p "Confermi? (y/n): " confirm
if [[ $confirm != "y" && $confirm != "Y" ]]; then
    print_warning "Deploy annullato"
    exit 0
fi

echo ""
print_info "Inizio deploy..."
echo ""

# Step 1: Configura Git (se necessario)
print_info "Step 1/6: Configurazione Git..."

git config --global user.name "$github_username" 2>/dev/null
git config --global user.email "$github_email" 2>/dev/null

print_success "Git configurato"
echo ""

# Step 2: Inizializza repository
print_info "Step 2/6: Inizializzazione repository..."

if [ -d .git ]; then
    print_warning "Repository già inizializzato"
else
    git init
    print_success "Repository inizializzato"
fi
echo ""

# Step 3: Aggiungi tutti i file
print_info "Step 3/6: Aggiunta file..."

git add .
print_success "File aggiunti allo stage"
echo ""

# Step 4: Primo commit
print_info "Step 4/6: Creazione commit..."

commit_message="Initial commit - VINCENT SALVATORE BPA v1.1.0

- Complete business productivity analyzer
- Custom company names feature
- 10+ productivity metrics
- Interactive charts and insights
- Full documentation
"

git commit -m "$commit_message"
print_success "Commit creato"
echo ""

# Step 5: Collega a GitHub
print_info "Step 5/6: Collegamento a GitHub..."

remote_url="https://github.com/$github_username/$repo_name.git"
git remote remove origin 2>/dev/null
git remote add origin $remote_url

print_success "Collegato a: $remote_url"
echo ""

# Step 6: Push su GitHub
print_info "Step 6/6: Push su GitHub..."
echo ""
print_warning "Ti verrà chiesto di autenticarti con GitHub"
print_info "Usa il tuo username e Personal Access Token come password"
echo ""

git branch -M main
git push -u origin main

if [ $? -eq 0 ]; then
    print_success "Push completato!"
    echo ""
    echo "=========================================="
    echo "🎉 DEPLOY COMPLETATO CON SUCCESSO!"
    echo "=========================================="
    echo ""
    print_info "Il tuo repository è ora su GitHub:"
    echo "  https://github.com/$github_username/$repo_name"
    echo ""
    print_info "Per abilitare GitHub Pages:"
    echo "  1. Vai su: https://github.com/$github_username/$repo_name/settings/pages"
    echo "  2. Source: Deploy from a branch"
    echo "  3. Branch: main"
    echo "  4. Folder: / (root)"
    echo "  5. Click 'Save'"
    echo ""
    print_info "Il tuo sito sarà disponibile a:"
    echo "  https://$github_username.github.io/$repo_name/"
    echo ""
    print_warning "Nota: GitHub Pages può richiedere 1-2 minuti per attivarsi"
    echo ""
else
    print_error "Errore durante il push"
    echo ""
    print_info "Possibili soluzioni:"
    echo "  1. Verifica che il repository esista su GitHub"
    echo "  2. Crea il repository su github.com prima di eseguire questo script"
    echo "  3. Verifica le tue credenziali GitHub"
    echo "  4. Usa un Personal Access Token invece della password"
    echo ""
    print_info "Come creare un Personal Access Token:"
    echo "  1. Vai su: https://github.com/settings/tokens"
    echo "  2. Click 'Generate new token (classic)'"
    echo "  3. Seleziona scope: 'repo'"
    echo "  4. Genera e copia il token"
    echo "  5. Usa il token come password quando Git lo chiede"
    echo ""
    exit 1
fi

echo ""
print_success "Script completato!"
echo ""
