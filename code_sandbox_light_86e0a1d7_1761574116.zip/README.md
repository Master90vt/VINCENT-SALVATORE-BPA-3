# 📊 VINCENT SALVATORE Business Productivity Analyzer

> **Advanced Comparative Analysis Tool for Measuring Business Productivity & Profitability Efficiency**

A sophisticated web application that compares two companies on productivity and profitability metrics, normalizes results by time period, and generates actionable insights with data-driven recommendations.

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![JavaScript](https://img.shields.io/badge/javascript-ES6+-yellow.svg)

---

## 🌟 Features

### ✅ Currently Implemented

#### **1. Comprehensive Input System**
- **Custom company names** for personalized reports
- Revenue, Profit, Employees, Hours worked
- Multiple time periods (week, month, quarter, half-year, year)
- Optional COGS and Operating Costs for GVA analysis
- Notes/tags for context (seasonal, one-off projects)
- Real-time validation with helpful error messages

#### **2. Advanced Metrics Calculation**
- **Revenue per Employee (RPE)** - Productivity per headcount
- **Profit per Employee (PPE)** - Profitability per headcount
- **Revenue per Labor Hour (RPH)** - Time efficiency
- **Profit per Labor Hour (PPH)** - Time profitability
- **Profit Margin** - Overall profitability percentage
- **Gross Value Added (GVA)** - Economic value creation (when COGS provided)
- **Labor Intensity** - Average hours per employee
- **Output Elasticity Proxy** - Revenue sensitivity to labor
- **Annualized Metrics** - All metrics normalized to annual equivalents

#### **3. Composite Productivity Index (CPI)**
- Weighted z-score methodology combining 4 key metrics:
  - RPH (default weight: 35%)
  - RPE (default weight: 25%)
  - PPH (default weight: 25%)
  - PPE (default weight: 15%)
- **Interactive weight adjustment** - Explore different strategic priorities
- Real-time recalculation when weights change
- Normalized 0-100 scoring for easy comparison

#### **4. Rich Data Visualizations**
- **Comparison Cards** - Side-by-side metric comparison with winner badges
- **Bar Charts** - Visual comparison of RPH, RPE, PPH, PPE
- **Radar Charts** - Multi-dimensional CPI component analysis
- **Waterfall Charts** - Revenue → COGS → GVA → OpEx → Profit breakdown
- Responsive charts with dark mode support

#### **5. Executive Insights Engine**
Generates plain-English insights answering:
- **Who is more productive and why?** (references top 2-3 driving metrics)
- **Time leverage analysis** - RPH and PPH differential explanations
- **Human capital efficiency** - RPE/PPE and labor intensity commentary
- **Profit architecture** - Cost structure and pricing strategy insights
- **Weight sensitivity** - How changing priorities affects the winner
- **Risk flags** - Seasonal notes, missing data, outliers

#### **6. Actionable Recommendations Playbook**
Tailored, ranked suggestions across 6 categories:
1. **Throughput & Pricing** - Yield management, A/B testing, product mix optimization
2. **Process & Automation** - Task automation, workflow optimization, self-serve
3. **Talent & Incentives** - Performance incentives, upskilling, engagement
4. **Cost Discipline** - COGS negotiation, waste reduction, supplier consolidation
5. **Product Strategy** - SKU-level profitability, portfolio optimization
6. **Time Leverage** - Decision standardization, delegation frameworks

Each recommendation includes:
- Priority level (High/Medium/Low)
- Target improvement range (e.g., "+10-15% RPH")
- Implementation timeframe (e.g., "60-90 days")
- Target metric for tracking

#### **7. Export & Sharing**
- **CSV Export** - Complete data export for spreadsheet analysis
- **Print to PDF** - Browser-native PDF generation
- **Full HTML Report** - Comprehensive standalone report download
- **Copy to Clipboard** - Quick sharing of insights section

#### **8. User Experience**
- **Dark/Light Mode** - Automatic theme persistence
- **Save/Load Scenarios** - LocalStorage-based scenario management
- **Example Data** - Pre-loaded examples for testing
- **Responsive Design** - Mobile-first, works on all devices
- **Accessibility** - WCAG AA compliant
- **Summary Ribbon** - Top-level KPIs always visible after calculation

#### **9. Educational Content**
- **"Why Productivity Matters" panel** explaining:
  - Macro impact (wages without inflation)
  - Micro benefits (better pay, pricing, profit)
  - Investor view (EBITDA growth engine)

---

## 🚀 Getting Started

### **Option 1: Direct Use**
Simply open `index.html` in any modern web browser. No installation or build process required!

### **Option 2: Local Server**
```bash
# Using Python 3
python -m http.server 8000

# Using Node.js
npx http-server

# Then open: http://localhost:8000
```

---

## 📖 Usage Guide

### **Step 1: Input Company Data**
1. Fill in the form for **Company A** and **Company B**
2. Required fields:
   - Revenue (currency)
   - Number of Employees (integer ≥ 1)
   - Total Hours Worked (numeric ≥ 1)
   - Reference Period (week/month/quarter/half-year/year)
3. Optional fields:
   - Profit (if 0 or missing, profit-based metrics will be limited)
   - COGS (enables GVA calculations)
   - Other Operating Costs (for detailed waterfall)
   - Notes/Tags (for context)

### **Step 2: Calculate**
Click **"Calculate & Analyze Productivity"** to generate results.

### **Step 3: Review Results**
- **Summary Ribbon** - Overall winner, CPI gap, best metric
- **Comparison Cards** - 6 key metrics with winner badges and deltas
- **Charts** - Bar chart (metrics), Radar chart (CPI), Waterfall (if COGS provided)

### **Step 4: Adjust CPI Weights (Optional)**
Use the weight sliders to explore different strategic priorities:
- **Throughput Priority** → Increase RPH weight
- **Profit Focus** → Increase PPH weight
- **Employee Efficiency** → Increase RPE/PPE weights

Watch how the winner changes based on your priorities!

### **Step 5: Explore Insights**
Read the **Executive Insights** section for:
- Winner analysis
- Time leverage breakdown
- Human capital efficiency
- Profit architecture commentary
- Risk flags and warnings

### **Step 6: Review Recommendations**
Check the **Actionable Recommendations** for specific, prioritized steps to improve productivity.

### **Step 7: Export**
- **Export CSV** - For spreadsheet analysis
- **Print to PDF** - For presentations/reports
- **Download Full Report** - Standalone HTML document
- **Copy Insights** - Quick share via clipboard

---

## 🧮 Example Calculation

### **Company A - Traditional Retail**
- Revenue: $50,000
- Profit: $5,000
- Employees: 10
- Hours: 1,500
- Period: 1 Month

**Calculated Metrics:**
- RPH = $50,000 / 1,500 = **$33.33/hr**
- RPE = $50,000 / 10 = **$5,000/employee**
- PPH = $5,000 / 1,500 = **$3.33/hr**
- PPE = $5,000 / 10 = **$500/employee**
- Profit Margin = $5,000 / $50,000 = **10%**

### **Company B - Digital Consultancy**
- Revenue: $10,000
- Profit: $4,000
- Employees: 1
- Hours: 10
- Period: 1 Month

**Calculated Metrics:**
- RPH = $10,000 / 10 = **$1,000/hr** (30× higher!)
- RPE = $10,000 / 1 = **$10,000/employee** (2× higher)
- PPH = $4,000 / 10 = **$400/hr** (120× higher!)
- PPE = $4,000 / 1 = **$4,000/employee** (8× higher)
- Profit Margin = $4,000 / $10,000 = **40%**

**Result:** Company B dramatically outperforms on per-hour and per-employee efficiency, demonstrating superior time leverage and business model scalability.

---

## 📊 Metrics Explained

### **Core Productivity Metrics**

| Metric | Formula | What It Measures | Why It Matters |
|--------|---------|------------------|----------------|
| **RPH** | Revenue ÷ Total Hours | How much revenue is generated per labor hour | Time efficiency - critical for scaling |
| **RPE** | Revenue ÷ Employees | Revenue productivity per headcount | Human capital efficiency |
| **PPH** | Profit ÷ Total Hours | Profit captured per labor hour | Time profitability - sustainable growth |
| **PPE** | Profit ÷ Employees | Profit per headcount | Employee value creation |
| **Margin** | Profit ÷ Revenue | Profitability percentage | Business model quality |
| **GVA** | Revenue − COGS | Economic value added | Real value creation |
| **Labor Intensity** | Hours ÷ Employees | Avg hours per employee | Workload and efficiency |
| **CPI** | Weighted z-score blend | Overall productivity index | Holistic comparison |

### **Why These Metrics?**

1. **RPH & PPH** - Time is the ultimate constraint. These show value creation per hour.
2. **RPE & PPE** - Headcount is expensive. These show return on human capital.
3. **Margin** - Reveals pricing power and cost discipline.
4. **GVA** - Shows true economic value after direct costs.
5. **CPI** - Combines multiple dimensions into a single, weighted score.

---

## 🎯 Validation & Edge Cases

### **Built-in Validations**
- ✅ Revenue must be > 0
- ✅ Employees must be ≥ 1
- ✅ Hours must be > 0
- ✅ Profit cannot exceed Revenue
- ✅ COGS cannot exceed Revenue

### **Warnings Triggered**
- ⚠️ Profit margin > 80% (unusually high)
- ⚠️ Negative profit margin (losing money)
- ⚠️ Hours per employee exceeds reasonable limits
- ⚠️ Seasonal business notes detected
- ⚠️ One-off project flags
- ⚠️ Missing profit data

### **Graceful Degradation**
- If profit = 0, PPH and PPE show as 0, margin grayed out
- If COGS not provided, GVA section hidden
- If both companies tied, special "parity" insight generated

---

## 🏗️ Technical Architecture

### **Tech Stack**
- **HTML5** - Semantic structure
- **Tailwind CSS** (CDN) - Utility-first styling
- **Vanilla JavaScript (ES6+)** - Modern, modular code
- **Chart.js** (CDN) - Rich, responsive visualizations
- **Font Awesome** (CDN) - Icon library
- **Google Fonts** (Inter) - Typography

### **File Structure**
```
vincent-salvatore-business-productivity-analyzer/
├── index.html              # Main HTML structure
├── js/
│   ├── app.js             # Core app logic, forms, theme, state
│   ├── calculator.js      # Metrics calculations, CPI, validations
│   ├── insights.js        # Insights engine, recommendations
│   ├── charts.js          # Chart.js visualizations
│   └── export.js          # CSV, PDF, report exports
└── README.md              # This file
```

### **Data Flow**
1. User inputs → Form validation → AppState
2. AppState → calculateMetrics() → Results A & B
3. Results → calculateCPI() → CPI scores
4. Results + CPI → generateInsights() → Executive insights
5. Results + CPI → generateRecommendations() → Action items
6. Results + CPI → renderCharts() → Visualizations

### **State Management**
Global `AppState` object stores:
- Company A & B input data
- Calculated results (metricsA, metricsB)
- CPI weights (adjustable)
- Chart instances
- Theme preference

### **LocalStorage Usage**
- Theme preference (`theme`)
- Saved scenarios (`scenarios` object)

---

## 🎨 Design Features

### **Responsive Design**
- Mobile-first approach
- Breakpoints: sm (640px), md (768px), lg (1024px)
- Touch-friendly controls
- Responsive charts and tables

### **Dark Mode**
- System preference detection
- Manual toggle
- Persistent across sessions
- Charts automatically adjust colors

### **Accessibility (WCAG AA)**
- Semantic HTML structure
- ARIA labels where needed
- Keyboard navigation support
- Sufficient color contrast
- Alt text for icons
- Focus indicators

### **Print Optimization**
- Print-specific CSS (`@media print`)
- Hides interactive controls (`.no-print`)
- Optimized chart sizes
- Page break management

---

## 🔧 Customization

### **Adjust Default CPI Weights**
Edit in `js/app.js`:
```javascript
cpiWeights: {
    rph: 0.35,  // Change these values
    rpe: 0.25,
    pph: 0.25,
    ppe: 0.15
}
```

### **Add New Metrics**
1. Calculate in `calculateMetrics()` in `calculator.js`
2. Add to comparison cards in `generateComparisonCards()`
3. Update charts in `charts.js`
4. Update CSV export in `export.js`

### **Customize Insights Logic**
Edit functions in `js/insights.js`:
- `generateWinnerInsight()`
- `generateTimeLeverageInsight()`
- `generateHumanCapitalInsight()`
- etc.

### **Change Color Scheme**
Edit Tailwind colors in `index.html` `<script>` block:
```javascript
tailwind.config = {
    theme: {
        extend: {
            colors: {
                primary: { /* your colors */ }
            }
        }
    }
}
```

---

## 🧪 Testing

### **Manual Testing Checklist**

**Input Validation:**
- [ ] Revenue = 0 → Error
- [ ] Employees = 0 → Error
- [ ] Hours = 0 → Error
- [ ] Profit > Revenue → Error
- [ ] COGS > Revenue → Error
- [ ] Missing period → Error

**Calculations:**
- [ ] RPH = Revenue / Hours ✓
- [ ] RPE = Revenue / Employees ✓
- [ ] PPH = Profit / Hours ✓
- [ ] PPE = Profit / Employees ✓
- [ ] Margin = Profit / Revenue ✓

**CPI:**
- [ ] Weight changes update CPI ✓
- [ ] Winner changes with weights ✓
- [ ] Z-scores calculated correctly ✓

**Warnings:**
- [ ] Margin > 80% triggers warning ✓
- [ ] High hours/employee triggers warning ✓
- [ ] "seasonal" in notes triggers flag ✓

**Exports:**
- [ ] CSV downloads correctly ✓
- [ ] Print to PDF works ✓
- [ ] HTML report generates ✓
- [ ] Copy to clipboard works ✓

**Scenarios:**
- [ ] Save scenario works ✓
- [ ] Load scenario works ✓
- [ ] LocalStorage persists ✓

**Responsive:**
- [ ] Mobile (< 640px) ✓
- [ ] Tablet (640-1024px) ✓
- [ ] Desktop (> 1024px) ✓

---

## 📚 Resources & References

### **Productivity Concepts**
- [OECD Productivity Statistics](https://www.oecd.org/sdd/productivity-stats/)
- [Understanding Gross Value Added (GVA)](https://www.investopedia.com/terms/g/gva.asp)
- [Labor Productivity Metrics](https://hbr.org/topic/productivity)

### **Libraries Used**
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [Chart.js Documentation](https://www.chartjs.org/docs)
- [Font Awesome Icons](https://fontawesome.com/icons)

---

## 🛣️ Roadmap

### **Not Yet Implemented (Future Enhancements)**

1. **Multi-Company Comparison** - Compare 3+ companies simultaneously
2. **Historical Tracking** - Track productivity over multiple periods
3. **Industry Benchmarks** - Compare against industry averages
4. **Goal Setting** - Set targets and track progress
5. **Advanced Filters** - Filter by tags, period, industry
6. **Export to Excel** - Native XLSX export
7. **API Integration** - Connect to accounting/HR systems
8. **Team Collaboration** - Share scenarios with team members
9. **Advanced Analytics** - Regression analysis, forecasting
10. **Custom Report Templates** - Branded report generation

### **Recommended Next Steps**

**For Users:**
1. Test with your own company data
2. Explore different CPI weight scenarios
3. Implement top 3 recommendations
4. Track improvements over time
5. Share insights with stakeholders

**For Developers:**
1. Add multi-company support
2. Implement historical tracking
3. Create API for data import
4. Add more chart types (line, scatter)
5. Build export to Excel (XLSX)

---

## 🤝 Contributing

This is an open project! Contributions welcome:

1. **Report Bugs** - Open an issue with details
2. **Suggest Features** - Describe use cases
3. **Submit PRs** - Fork, code, test, PR
4. **Improve Docs** - Clarify, expand, translate

---

## 📄 License

MIT License - feel free to use, modify, and distribute.

---

## 🙏 Acknowledgments

Built with modern web technologies and best practices in mind. Special thanks to:
- Tailwind CSS team for the amazing utility framework
- Chart.js contributors for powerful visualization
- Open source community for inspiration

---

## 📞 Support

**Questions? Issues? Feedback?**

This is a client-side only application - all calculations happen in your browser. Your data never leaves your device.

For technical questions or feature requests, please refer to the documentation above or review the inline code comments.

---

## 🎓 Learn More

### **Key Takeaways**
1. **Productivity = Output / Input** - Maximize value per hour and per employee
2. **Time is the ultimate constraint** - RPH and PPH are critical
3. **Margins matter** - High throughput with low margins isn't sustainable
4. **Compounding matters** - Small productivity gains compound over time
5. **Measurement drives improvement** - What gets measured gets managed

### **Why This Tool?**
Traditional business analysis focuses on absolute numbers (revenue, profit). This tool focuses on **efficiency ratios** - how much value you create per unit of input (time, people). This reveals the true productivity story and identifies leverage points for growth.

**Use this tool to:**
- Compare business models objectively
- Identify productivity gaps
- Prioritize improvement initiatives
- Track progress over time
- Make data-driven strategic decisions

---

**VINCENT SALVATORE Business Productivity Analyzer**

Built with ❤️ for business leaders, entrepreneurs, and productivity enthusiasts

*Version 1.0.0 | Last Updated: 2024*
