# 🏗️ VINCENT SALVATORE - Technical Architecture

## Overview

VINCENT SALVATORE Business Productivity Analyzer is a **client-side single-page application (SPA)** built with vanilla JavaScript, HTML5, and Tailwind CSS. All data processing happens in the browser - no server required.

---

## 📐 Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                     BROWSER (Client-Side)                    │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              index.html (Entry Point)                  │  │
│  │  • HTML5 Structure                                     │  │
│  │  • Tailwind CSS (CDN)                                  │  │
│  │  • Font Awesome Icons                                  │  │
│  │  • Google Fonts (Inter)                                │  │
│  └───────────────────────────────────────────────────────┘  │
│                            ↓                                  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              JavaScript Modules (5 files)              │  │
│  │                                                         │  │
│  │  ┌─────────────────────────────────────────────────┐  │  │
│  │  │  app.js (17 KB)                                 │  │  │
│  │  │  • Application initialization                   │  │  │
│  │  │  • Form generation & validation                 │  │  │
│  │  │  • State management (AppState)                  │  │  │
│  │  │  • Event handling                               │  │  │
│  │  │  • Theme management (dark/light)                │  │  │
│  │  │  • Scenario save/load (localStorage)            │  │  │
│  │  └─────────────────────────────────────────────────┘  │  │
│  │                                                         │  │
│  │  ┌─────────────────────────────────────────────────┐  │  │
│  │  │  calculator.js (17 KB)                          │  │  │
│  │  │  • Metrics calculations (RPH, PPH, RPE, PPE)    │  │  │
│  │  │  • CPI calculation (weighted z-scores)          │  │  │
│  │  │  • Annualization logic                          │  │  │
│  │  │  • Validation & warnings                        │  │  │
│  │  │  • Weight normalization                         │  │  │
│  │  │  • Comparison cards generation                  │  │  │
│  │  └─────────────────────────────────────────────────┘  │  │
│  │                                                         │  │
│  │  ┌─────────────────────────────────────────────────┐  │  │
│  │  │  insights.js (26 KB)                            │  │  │
│  │  │  • Winner analysis                              │  │  │
│  │  │  • Time leverage insights                       │  │  │
│  │  │  • Human capital analysis                       │  │  │
│  │  │  • Profit architecture insights                 │  │  │
│  │  │  • Weight sensitivity analysis                  │  │  │
│  │  │  • Risk flags                                   │  │  │
│  │  │  • Recommendations engine (6 categories)        │  │  │
│  │  └─────────────────────────────────────────────────┘  │  │
│  │                                                         │  │
│  │  ┌─────────────────────────────────────────────────┐  │  │
│  │  │  charts.js (13 KB)                              │  │  │
│  │  │  • Bar chart (metrics comparison)               │  │  │
│  │  │  • Radar chart (CPI components)                 │  │  │
│  │  │  • Waterfall charts (profit analysis)           │  │  │
│  │  │  • Theme-aware colors                           │  │  │
│  │  │  • Responsive sizing                            │  │  │
│  │  │  • Chart.js integration                         │  │  │
│  │  └─────────────────────────────────────────────────┘  │  │
│  │                                                         │  │
│  │  ┌─────────────────────────────────────────────────┐  │  │
│  │  │  export.js (18 KB)                              │  │  │
│  │  │  • CSV export                                   │  │  │
│  │  │  • Print to PDF (browser native)                │  │  │
│  │  │  • Full HTML report generation                  │  │  │
│  │  │  • Copy to clipboard                            │  │  │
│  │  └─────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────┘  │
│                            ↓                                  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              External Libraries (CDN)                  │  │
│  │  • Chart.js v4.4.0 - Visualizations                   │  │
│  │  • Tailwind CSS - Styling                             │  │
│  │  • Font Awesome v6.5.1 - Icons                        │  │
│  │  • Google Fonts (Inter) - Typography                  │  │
│  └───────────────────────────────────────────────────────┘  │
│                            ↓                                  │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              Browser Storage (Optional)                │  │
│  │  • localStorage - Theme preference                     │  │
│  │  • localStorage - Saved scenarios                     │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                               │
└───────────────────────────────────────────────────────────────┘

NO SERVER REQUIRED - 100% CLIENT-SIDE
```

---

## 🔄 Data Flow

```
┌─────────────┐
│   USER      │
│   INPUT     │
└──────┬──────┘
       │
       ↓
┌─────────────────────────────────────┐
│  Form Validation (app.js)          │
│  • Check required fields            │
│  • Validate business logic          │
│  • Display errors if any            │
└──────┬──────────────────────────────┘
       │
       ↓
┌─────────────────────────────────────┐
│  Store in AppState (app.js)        │
│  {                                  │
│    companyA: {...},                 │
│    companyB: {...},                 │
│    cpiWeights: {...}                │
│  }                                  │
└──────┬──────────────────────────────┘
       │
       ↓
┌─────────────────────────────────────┐
│  Calculate Metrics (calculator.js) │
│  • Basic metrics (RPH, PPH, etc.)   │
│  • Annualized versions              │
│  • GVA (if COGS provided)           │
│  • Labor intensity                  │
│  • Warnings/flags                   │
└──────┬──────────────────────────────┘
       │
       ↓
┌─────────────────────────────────────┐
│  Calculate CPI (calculator.js)     │
│  • Z-score normalization            │
│  • Apply weights                    │
│  • Determine winner                 │
│  • Calculate gap                    │
└──────┬──────────────────────────────┘
       │
       ├────────────────────────────────────────┐
       │                                        │
       ↓                                        ↓
┌──────────────────────┐          ┌────────────────────────┐
│  Generate Insights   │          │  Render Charts         │
│  (insights.js)       │          │  (charts.js)           │
│  • Winner analysis   │          │  • Bar chart           │
│  • Time leverage     │          │  • Radar chart         │
│  • Human capital     │          │  • Waterfall           │
│  • Profit arch.      │          └────────────────────────┘
│  • Sensitivity       │                     │
│  • Risk flags        │                     │
└──────┬───────────────┘                     │
       │                                     │
       ↓                                     │
┌──────────────────────┐                    │
│  Generate Recommen-  │                    │
│  dations             │                    │
│  (insights.js)       │                    │
│  • 6 categories      │                    │
│  • Prioritized       │                    │
│  • With targets      │                    │
└──────┬───────────────┘                    │
       │                                     │
       └─────────────┬───────────────────────┘
                     │
                     ↓
            ┌────────────────┐
            │  UPDATE UI     │
            │  • Cards       │
            │  • Charts      │
            │  • Insights    │
            │  • Recommend.  │
            └────────────────┘
```

---

## 🗂️ Module Responsibilities

### **app.js** - Core Application
```javascript
Responsibilities:
├── Application initialization
├── Form generation (dynamic fields)
├── Input validation
├── State management (AppState object)
├── Event handling (buttons, sliders)
├── Theme management (dark/light mode)
├── Scenario save/load (localStorage)
├── Loading states
└── Error handling

Key Functions:
├── generateForm() - Create input forms
├── collectFormData() - Extract user input
├── validateData() - Validate business logic
├── loadExampleData() - Populate example
├── saveScenario() - Save to localStorage
├── loadScenario() - Restore from localStorage
├── toggleTheme() - Switch dark/light mode
└── handleCalculate() - Orchestrate calculation flow
```

### **calculator.js** - Calculations & Metrics
```javascript
Responsibilities:
├── Calculate all productivity metrics
├── Compute Composite Productivity Index (CPI)
├── Annualize metrics based on period
├── Generate warnings/flags
├── Normalize weights
├── Compare companies
├── Update summary ribbon
└── Generate comparison cards

Key Functions:
├── calculateMetrics() - Calculate 10+ metrics
├── calculateCPI() - Compute weighted z-score CPI
├── normalizeWeights() - Ensure weights sum to 1.0
├── updateSummaryRibbon() - Update top KPIs
├── generateComparisonCards() - Create metric cards
└── findBestMetric() - Identify largest gap

Formulas Implemented:
├── RPE = Revenue ÷ Employees
├── PPE = Profit ÷ Employees
├── RPH = Revenue ÷ Hours
├── PPH = Profit ÷ Hours
├── Margin = Profit ÷ Revenue
├── GVA = Revenue − COGS
├── Labor Intensity = Hours ÷ Employees
├── Output Elasticity = RPH ÷ PPE
└── CPI = Σ(z-score × weight) for each component
```

### **insights.js** - Intelligence Layer
```javascript
Responsibilities:
├── Generate executive insights (6 types)
├── Explain winner and why
├── Analyze time leverage
├── Evaluate human capital efficiency
├── Comment on profit architecture
├── Test weight sensitivity
├── Flag risks and warnings
└── Generate actionable recommendations

Key Functions:
├── generateInsights() - Orchestrate all insights
├── generateWinnerInsight() - Winner analysis
├── generateTimeLeverageInsight() - RPH/PPH analysis
├── generateHumanCapitalInsight() - RPE/PPE analysis
├── generateProfitArchitectureInsight() - Margin/throughput
├── generateWeightSensitivityInsight() - Scenario testing
├── generateRiskFlagsInsight() - Warnings summary
└── generateRecommendations() - 6 categories of actions

Recommendation Categories:
├── 1. Throughput & Pricing
├── 2. Process & Automation
├── 3. Talent & Incentives
├── 4. Cost Discipline
├── 5. Product Strategy
└── 6. Time Leverage
```

### **charts.js** - Visualizations
```javascript
Responsibilities:
├── Render bar chart (metrics comparison)
├── Render radar chart (CPI components)
├── Render waterfall charts (profit breakdown)
├── Handle theme-aware colors
├── Manage chart responsiveness
└── Destroy/recreate on updates

Key Functions:
├── renderCharts() - Orchestrate all charts
├── renderBarChart() - Metrics comparison
├── renderRadarChart() - CPI components
├── renderWaterfallCharts() - Profit waterfall
├── getChartColors() - Theme-based colors
├── getCommonChartOptions() - Shared config
└── destroyAllCharts() - Cleanup

Chart.js Integration:
├── Bar charts for metric comparison
├── Radar charts for multi-dimensional view
└── Stacked bars for waterfall analysis
```

### **export.js** - Data Export
```javascript
Responsibilities:
├── Export to CSV format
├── Print to PDF (browser native)
├── Generate full HTML report
├── Copy insights to clipboard
└── Format data for export

Key Functions:
├── exportToCSV() - Generate CSV file
├── printToPDF() - Trigger browser print
├── downloadFullReport() - Create HTML report
├── copyInsightsToClipboard() - Copy text
└── downloadFile() - Blob download utility

Export Formats:
├── CSV - Structured data for spreadsheets
├── PDF - Via browser print dialog
├── HTML - Standalone formatted report
└── Plain text - For clipboard sharing
```

---

## 💾 State Management

### **Global AppState Object**

```javascript
AppState = {
  // Input data
  companyA: {
    revenue: Number,
    profit: Number,
    employees: Number,
    hours: Number,
    period: String,
    periodFactor: Number,
    cogs: Number,
    opex: Number,
    notes: String
  },
  
  companyB: { /* same structure */ },
  
  // Calculated results
  resultsA: {
    // Basic metrics
    revenue, profit, employees, hours, period,
    rpe, ppe, rph, pph, profitMargin,
    
    // GVA metrics (if COGS provided)
    gva, gvaPerEmployee, gvaPerHour,
    
    // Annualized metrics
    annualizedRPE, annualizedPPE,
    annualizedRPH, annualizedPPH,
    annualizedGVA, annualizedGVAPerEmployee, annualizedGVAPerHour,
    
    // Additional metrics
    laborIntensity, outputElasticity,
    
    // Warnings
    warnings: [
      { type, message, icon, color }
    ]
  },
  
  resultsB: { /* same structure */ },
  
  // CPI weights (adjustable)
  cpiWeights: {
    rph: 0.35,
    rpe: 0.25,
    pph: 0.25,
    ppe: 0.15
  },
  
  // Chart instances
  charts: {
    barChart: Chart,
    radarChart: Chart,
    waterfallChartA: Chart,
    waterfallChartB: Chart
  },
  
  // UI state
  darkMode: Boolean
}
```

### **LocalStorage Schema**

```javascript
// Theme preference
localStorage.theme = "dark" | "light"

// Saved scenarios
localStorage.scenarios = {
  "Scenario Name 1": {
    companyA: { /* data */ },
    companyB: { /* data */ },
    weights: { /* CPI weights */ },
    timestamp: "2024-10-27T12:00:00.000Z"
  },
  "Scenario Name 2": { /* ... */ }
}
```

---

## 🔄 Event Flow

### **1. Page Load**
```
DOMContentLoaded
  ↓
initTheme() - Load theme from localStorage
  ↓
generateForm('formA') - Create Company A form
generateForm('formB') - Create Company B form
  ↓
attachEventListeners() - Attach all event handlers
  ↓
checkSavedState() - Check for saved scenarios
  ↓
Ready! 🎉
```

### **2. Calculate Button Click**
```
handleCalculate()
  ↓
showLoading(true)
  ↓
collectFormData('A') - Extract Company A data
collectFormData('B') - Extract Company B data
  ↓
validateData(dataA) - Validate Company A
validateData(dataB) - Validate Company B
  ↓
[If validation fails] → Show errors → Stop
[If validation passes] → Continue
  ↓
calculateMetrics(dataA) → resultsA
calculateMetrics(dataB) → resultsB
  ↓
updateSummaryRibbon() - Update top ribbon
generateWeightControls() - Create weight sliders
generateComparisonCards() - Create metric cards
renderCharts() - Render all charts
generateInsights() - Generate insights
generateRecommendations() - Generate recommendations
  ↓
Show results sections
Scroll to results
showLoading(false)
  ↓
Done! ✅
```

### **3. Weight Slider Change**
```
Weight slider input event
  ↓
Update AppState.cpiWeights[key]
  ↓
normalizeWeights() - Ensure sum = 1.0
  ↓
Update all weight displays
  ↓
updateAfterWeightChange()
  ↓
Recalculate CPI
Update comparison cards
Re-render charts
Update summary ribbon
  ↓
[If winner changed] → Log warning
  ↓
Done! ✅
```

---

## 🎨 UI Component Hierarchy

```
<body>
  <header> - Sticky navigation
    <h1>VINCENT SALVATORE</h1>
    <theme-toggle>
    <save-button>
    <load-button>
  
  <summary-ribbon> - Top KPIs (hidden initially)
    <winner>
    <cpi-gap>
    <best-metric>
    <period>
  
  <main>
    <why-productivity-panel> - Educational content
    
    <section id="inputSection">
      <h2>Company Inputs</h2>
      <form id="formA"> - Company A inputs
      <form id="formB"> - Company B inputs
      <calculate-button>
    
    <section id="resultsSection"> - Hidden initially
      <h2>Comparative Results</h2>
      <weight-controls> - CPI weight sliders
      <comparison-cards> - 6 metric cards
      <charts>
        <bar-chart>
        <radar-chart>
        <waterfall-charts>
    
    <section id="insightsSection"> - Hidden initially
      <h2>Insights & Recommendations</h2>
      <insights-content> - 6 insight cards
      <recommendations-content> - N recommendation cards
      <export-buttons>
  
  <footer> - Credits
  
  <loading-overlay> - Shown during calculations
```

---

## 🔧 Configuration

### **CDN Libraries**
```javascript
// Chart.js v4.4.0
https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.js

// Tailwind CSS (latest)
https://cdn.tailwindcss.com

// Font Awesome v6.5.1
https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.1/css/all.min.css

// Google Fonts (Inter)
https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800
```

### **Tailwind Configuration**
```javascript
tailwind.config = {
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: {
          // Blue shades (50-900)
        }
      }
    }
  }
}
```

---

## 🛡️ Security & Privacy

### **Data Privacy**
- ✅ **100% client-side** - All processing in browser
- ✅ **No server communication** - No data sent anywhere
- ✅ **No tracking** - No analytics or telemetry
- ✅ **No accounts** - No login or registration
- ✅ **LocalStorage only** - Data stays on device
- ✅ **User controlled** - User can clear localStorage anytime

### **XSS Protection**
- ✅ All user inputs sanitized before display
- ✅ No eval() or dynamic code execution
- ✅ Content Security Policy compatible
- ✅ Safe innerHTML usage (only with trusted content)

---

## 📊 Performance

### **Load Performance**
- Initial HTML: ~18 KB (gzipped: ~5 KB)
- JavaScript: ~91 KB total (gzipped: ~20 KB)
- External CDNs: ~500 KB (cached after first load)
- **Total first load**: < 1 MB
- **Subsequent loads**: < 50 KB (CDNs cached)

### **Runtime Performance**
- Form validation: < 10ms
- Metric calculations: < 50ms
- CPI calculation: < 20ms
- Chart rendering: < 300ms per chart
- Insights generation: < 100ms
- **Total calculation time**: < 500ms

### **Memory Usage**
- AppState: ~10 KB
- Chart instances: ~500 KB
- DOM: ~1 MB
- **Total**: < 2 MB

---

## 🔄 Browser Compatibility

### **Supported Browsers**
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Opera 76+

### **Required Features**
- ES6+ JavaScript
- LocalStorage API
- Canvas API (for charts)
- CSS Grid & Flexbox
- CSS Custom Properties

---

## 📱 Responsive Breakpoints

```css
/* Mobile First */
Default: < 640px (mobile)

/* Tailwind Breakpoints */
sm: 640px  (large mobile, small tablet)
md: 768px  (tablet)
lg: 1024px (small desktop)
xl: 1280px (desktop)
2xl: 1536px (large desktop)

/* Critical Breakpoints Used */
Mobile: < 640px
  - Single column layout
  - Stacked forms
  - Full-width cards

Tablet: 640px - 1024px
  - Two-column forms
  - 2-column card grid
  - Condensed headers

Desktop: > 1024px
  - Two-column forms
  - 3-column card grid
  - Full charts side-by-side
```

---

## 🎯 Future Architecture Considerations

### **Phase 2: Enhanced Features**
- Multi-company comparison (3+)
- Historical data tracking
- IndexedDB for larger datasets
- Web Workers for heavy calculations

### **Phase 3: Integrations**
- REST API for data import
- WebSocket for real-time updates
- OAuth for secure sharing
- Cloud backup (optional)

### **Phase 4: Scaling**
- Service Worker for offline mode
- Progressive Web App (PWA)
- Native mobile apps (React Native)
- Desktop app (Electron)

---

**VINCENT SALVATORE Business Productivity Analyzer**  
*Technical Architecture v1.0.0*
