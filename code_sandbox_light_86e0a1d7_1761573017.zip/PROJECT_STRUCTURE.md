# 🏗️ Project Structure

Complete architecture and file organization of the Business Productivity Analyzer.

---

## 📁 Directory Structure

```
business-productivity-analyzer/
│
├── index.html                 # Main application entry point
│
├── js/                        # JavaScript modules
│   ├── app.js                 # Core application logic
│   ├── calculator.js          # Metrics calculations
│   ├── charts.js              # Chart.js visualizations
│   ├── insights.js            # Insights engine
│   └── export.js              # Export functionality
│
├── README.md                  # Main documentation
├── QUICK_START.md             # Quick start guide
├── EXAMPLES.md                # Example scenarios
├── FAQ.md                     # Frequently asked questions
├── CONTRIBUTING.md            # Contribution guidelines
├── CHANGELOG.md               # Version history
├── LICENSE                    # MIT License
├── .gitignore                 # Git ignore rules
├── package.json               # NPM package metadata
└── PROJECT_STRUCTURE.md       # This file
```

---

## 📄 File Descriptions

### Core Files

#### `index.html` (18 KB)
**Purpose:** Main HTML structure and UI layout

**Contents:**
- HTML5 semantic structure
- Tailwind CSS (CDN)
- Chart.js (CDN)
- Font Awesome icons (CDN)
- Google Fonts (Inter)
- Dark/Light mode setup
- Responsive layout sections:
  - Header with navigation
  - Summary ribbon
  - Input forms (Company A & B)
  - Results section (cards & charts)
  - Insights & recommendations
  - Footer

**Key Features:**
- No-print classes for exports
- Sticky header
- Responsive grid layouts
- Loading overlay
- Accessibility attributes

---

### JavaScript Modules

#### `js/app.js` (17 KB)
**Purpose:** Main application controller

**Responsibilities:**
- Application initialization
- Form generation and management
- Event listeners setup
- Theme management (dark/light)
- State management (`AppState` object)
- Input validation
- Scenario save/load
- Example data loading

**Key Functions:**
```javascript
initTheme()              // Initialize theme
generateForm()           // Dynamic form generation
handleCalculate()        // Main calculation flow
collectFormData()        // Gather form inputs
validateData()          // Validate inputs
toggleTheme()           // Switch dark/light mode
saveScenario()          // Save to localStorage
loadScenario()          // Load from localStorage
```

**Global State:**
```javascript
AppState = {
    companyA: {},        // Company A data
    companyB: {},        // Company B data
    resultsA: null,      // Calculated results A
    resultsB: null,      // Calculated results B
    cpiWeights: {},      // CPI component weights
    charts: {},          // Chart instances
    darkMode: true       // Theme preference
}
```

---

#### `js/calculator.js` (17 KB)
**Purpose:** All productivity calculations

**Responsibilities:**
- Metric calculations (RPH, RPE, PPH, PPE, etc.)
- CPI calculation with z-scores
- Weight normalization
- Annualization logic
- Warning detection
- Comparison card generation
- Weight control UI

**Key Functions:**
```javascript
calculateMetrics(data)           // Calculate all metrics
calculateCPI(metricsA, metricsB) // Calculate CPI
updateSummaryRibbon()            // Update top ribbon
generateWeightControls()         // Create weight sliders
normalizeWeights()               // Ensure weights sum to 1
updateAfterWeightChange()        // Recalculate on weight change
generateComparisonCards()        // Create metric cards
```

**Metrics Calculated:**
- Revenue per Employee (RPE)
- Profit per Employee (PPE)
- Revenue per Hour (RPH)
- Profit per Hour (PPH)
- Profit Margin
- Gross Value Added (GVA)
- GVA per Employee
- GVA per Hour
- Labor Intensity
- Output Elasticity
- Annualized versions of all above
- Composite Productivity Index (CPI)

---

#### `js/charts.js` (13 KB)
**Purpose:** Chart.js visualization rendering

**Responsibilities:**
- Bar chart (metric comparison)
- Radar chart (CPI components)
- Waterfall chart (profit breakdown)
- Theme-aware colors
- Chart destruction and recreation
- Responsive chart sizing

**Key Functions:**
```javascript
renderCharts()                  // Render all charts
renderBarChart()               // Bar chart
renderRadarChart()             // Radar chart
renderWaterfallCharts()        // Waterfall charts
getChartColors()               // Theme-based colors
getCommonChartOptions()        // Shared options
destroyAllCharts()             // Cleanup
```

**Chart Types:**
1. **Bar Chart**: Side-by-side comparison of RPH, PPH, RPE, PPE
2. **Radar Chart**: Multi-dimensional CPI visualization
3. **Waterfall Chart**: Revenue → COGS → GVA → OpEx → Profit

---

#### `js/insights.js` (26 KB)
**Purpose:** Insights engine and recommendations

**Responsibilities:**
- Executive insights generation
- Winner analysis
- Time leverage insights
- Human capital analysis
- Profit architecture insights
- Weight sensitivity analysis
- Risk flag detection
- Actionable recommendations

**Key Functions:**
```javascript
generateInsights()                      // Main insights generator
generateWinnerInsight()                 // Overall winner
generateTimeLeverageInsight()           // Time analysis
generateHumanCapitalInsight()           // People efficiency
generateProfitArchitectureInsight()     // Margin analysis
generateWeightSensitivityInsight()      // Weight scenarios
generateRiskFlagsInsight()              // Warnings
generateRecommendations()               // Action items
```

**Recommendation Categories:**
1. Throughput & Pricing
2. Process & Automation
3. Talent & Incentives
4. Cost Discipline
5. Product Strategy
6. Time Leverage

**Each Recommendation Includes:**
- Priority (High/Medium/Low)
- Description
- Target impact (e.g., "+10-15% RPH")
- Timeframe (e.g., "60-90 days")
- Target metric

---

#### `js/export.js` (18 KB)
**Purpose:** Export and sharing functionality

**Responsibilities:**
- CSV export
- PDF printing (browser-native)
- HTML report generation
- Copy to clipboard

**Key Functions:**
```javascript
exportToCSV()              // Export data to CSV
printToPDF()              // Print using browser
downloadFullReport()      // Generate HTML report
copyInsightsToClipboard() // Copy insights text
downloadFile()            // Download helper
```

**Export Formats:**
1. **CSV**: All inputs, metrics, CPI, warnings
2. **PDF**: Browser print (Ctrl+P / Cmd+P)
3. **HTML**: Standalone report with styling
4. **Text**: Insights copied to clipboard

---

## 📚 Documentation Files

### `README.md` (17 KB)
**Complete project documentation:**
- Feature overview
- Getting started guide
- Usage instructions
- Metrics explained
- Technical architecture
- Customization guide
- Testing checklist
- Roadmap

### `QUICK_START.md` (9 KB)
**Fast onboarding guide:**
- 5-minute quick start
- Try example data
- Analyze your business
- Explore features
- Troubleshooting
- Pro tips

### `EXAMPLES.md` (9 KB)
**Real-world scenarios:**
- 7 complete example scenarios
- Edge cases
- Learning scenarios
- Challenge exercises
- Expected results for each

### `FAQ.md` (14 KB)
**Common questions:**
- 50+ Q&A pairs
- General, privacy, usage
- Calculations, metrics
- Features, technical
- Troubleshooting, best practices

### `CONTRIBUTING.md` (10 KB)
**Contribution guide:**
- Code of conduct
- How to contribute
- Development setup
- Coding standards
- Commit guidelines
- PR process
- Testing requirements

### `CHANGELOG.md` (7 KB)
**Version history:**
- Version 1.0.0 features
- Planned future features
- Release roadmap
- Migration guides

### `LICENSE` (1 KB)
**MIT License:**
- Open source
- Free to use, modify, distribute

---

## 🎨 Design Architecture

### **Technology Stack**

```
Frontend:
├── HTML5 (Semantic)
├── Tailwind CSS v3 (Utility-first styling)
├── JavaScript ES6+ (Vanilla, no frameworks)
└── CDN Libraries:
    ├── Chart.js v4.4 (Visualizations)
    ├── Font Awesome v6.5 (Icons)
    └── Google Fonts (Inter)
```

### **Why These Choices?**

**Vanilla JavaScript:**
- ✅ No build process needed
- ✅ Fast loading
- ✅ Easy to understand
- ✅ No dependencies to manage
- ✅ Works offline after initial load

**Tailwind CSS:**
- ✅ Rapid UI development
- ✅ Consistent design system
- ✅ Built-in dark mode
- ✅ Responsive by default
- ✅ Small production size

**Chart.js:**
- ✅ Powerful and flexible
- ✅ Responsive charts
- ✅ Great documentation
- ✅ Theme customization
- ✅ Active community

---

## 🔄 Data Flow

```
User Input
    ↓
Form Validation (app.js)
    ↓
Data Collection (app.js)
    ↓
Metric Calculation (calculator.js)
    ↓
CPI Calculation (calculator.js)
    ↓
Results Storage (AppState)
    ↓
┌─────────────────────────────┐
│ UI Updates (parallel):      │
├─ Summary Ribbon             │
├─ Comparison Cards           │
├─ Weight Controls            │
├─ Charts (charts.js)         │
├─ Insights (insights.js)     │
└─ Recommendations            │
    ↓
User Actions:
├─ Export (export.js)
├─ Save Scenario (app.js)
└─ Adjust Weights → Recalculate
```

---

## 🎯 Module Responsibilities

### **Separation of Concerns**

| Module | Responsibility | Dependencies |
|--------|---------------|--------------|
| `app.js` | UI, State, Events | None (core) |
| `calculator.js` | Math, Metrics, CPI | app.js (AppState) |
| `charts.js` | Visualizations | calculator.js, app.js |
| `insights.js` | Analysis, Text | calculator.js, app.js |
| `export.js` | Output, Sharing | calculator.js, app.js |

### **Communication Pattern**

```
app.js (Controller)
    ├─→ calculator.js (Model) → Results
    ├─→ charts.js (View) → Reads Results
    ├─→ insights.js (View) → Reads Results
    └─→ export.js (Service) → Reads Results
```

---

## 💾 State Management

### **Global State (AppState)**

```javascript
AppState = {
    // Input data
    companyA: {
        revenue: number,
        profit: number,
        employees: number,
        hours: number,
        period: string,
        periodFactor: number,
        cogs: number,
        opex: number,
        notes: string
    },
    companyB: { /* same structure */ },
    
    // Calculated results
    resultsA: {
        // All metrics + warnings
        rph, rpe, pph, ppe,
        profitMargin, gva, laborIntensity,
        annualized metrics...
        warnings: []
    },
    resultsB: { /* same structure */ },
    
    // CPI configuration
    cpiWeights: {
        rph: 0.35,
        rpe: 0.25,
        pph: 0.25,
        ppe: 0.15
    },
    
    // UI state
    charts: {
        barChart: ChartInstance,
        radarChart: ChartInstance,
        waterfallChartA: ChartInstance,
        waterfallChartB: ChartInstance
    },
    darkMode: boolean
}
```

### **LocalStorage**

```javascript
localStorage.setItem('theme', 'dark' | 'light')
localStorage.setItem('scenarios', {
    "Scenario Name": {
        companyA: {...},
        companyB: {...},
        weights: {...},
        timestamp: ISO string
    }
})
```

---

## 🔧 Extension Points

### **Adding New Metrics**

1. **Calculate in calculator.js:**
```javascript
metrics.newMetric = /* calculation */;
```

2. **Add to comparison cards:**
```javascript
// In generateComparisonCards()
cards.push({ title: 'New Metric', ... });
```

3. **Update export:**
```javascript
// In export.js
csv += `New Metric,${metricsA.newMetric},${metricsB.newMetric}\n`;
```

### **Adding New Insights**

1. **Create function in insights.js:**
```javascript
function generateNewInsight(metricsA, metricsB) {
    return {
        title: '...',
        icon: '...',
        color: '...',
        content: '...',
        details: [...]
    };
}
```

2. **Add to insights array:**
```javascript
// In generateInsights()
insights.push(generateNewInsight(metricsA, metricsB));
```

### **Adding New Charts**

1. **Create function in charts.js:**
```javascript
function renderNewChart() {
    const canvas = document.getElementById('newChart');
    // Chart.js code
}
```

2. **Add canvas to index.html:**
```html
<canvas id="newChart"></canvas>
```

3. **Call in renderCharts():**
```javascript
renderNewChart();
```

---

## 🧪 Testing Strategy

### **Manual Testing**
- Browser compatibility
- Responsive design
- Dark/light mode
- Edge cases
- Export functionality

### **Test Data**
- Example scenarios in EXAMPLES.md
- Edge cases documented
- Industry benchmarks

### **Future: Automated Testing**
- Unit tests (Jest)
- Integration tests (Playwright)
- Visual regression (Percy)

---

## 📦 Build & Deployment

### **Current: Static Deployment**
No build process needed!
- Upload files to any static host
- Works on GitHub Pages, Netlify, Vercel
- Or run locally (double-click index.html)

### **Future: Build Process (Optional)**
```bash
# Minification
npm run build

# Testing
npm run test

# Linting
npm run lint
```

---

## 🚀 Performance

### **Load Time**
- HTML: ~18 KB
- JS (total): ~91 KB
- CSS: CDN (Tailwind)
- Charts: CDN (Chart.js)
- **Total First Load**: < 2 seconds on 3G

### **Optimizations**
- ✅ Minimal JavaScript
- ✅ CDN for large libraries
- ✅ Lazy chart rendering
- ✅ Efficient DOM updates
- ✅ No unnecessary re-renders

### **Future Optimizations**
- Code splitting
- Service worker (PWA)
- Local asset caching
- Preload critical resources

---

## 🔐 Security

### **Current Security**
- ✅ 100% client-side (no server)
- ✅ No data transmission
- ✅ No external API calls (except CDN)
- ✅ No authentication needed
- ✅ No cookies

### **Future Considerations**
- CSP headers (if hosted)
- SRI for CDN resources
- HTTPS enforcement

---

## ♿ Accessibility

### **WCAG AA Compliance**
- ✅ Semantic HTML
- ✅ ARIA labels
- ✅ Keyboard navigation
- ✅ Color contrast
- ✅ Alt text for icons
- ✅ Focus indicators
- ✅ Screen reader friendly

---

## 📱 Responsive Design

### **Breakpoints**
- **Mobile**: < 640px (sm)
- **Tablet**: 640px - 1024px (md)
- **Desktop**: > 1024px (lg)

### **Responsive Features**
- Stacked forms on mobile
- Hamburger menu (future)
- Touch-friendly controls
- Readable charts on small screens

---

## 🌐 Browser Support

| Browser | Version | Status |
|---------|---------|--------|
| Chrome  | 90+     | ✅ Fully supported |
| Firefox | 88+     | ✅ Fully supported |
| Safari  | 14+     | ✅ Fully supported |
| Edge    | 90+     | ✅ Fully supported |
| Mobile  | Latest  | ✅ Fully supported |

---

## 📊 Code Statistics

| File | Lines | Size | Purpose |
|------|-------|------|---------|
| index.html | 454 | 18 KB | UI Structure |
| app.js | 488 | 17 KB | Core Logic |
| calculator.js | 461 | 17 KB | Calculations |
| charts.js | 353 | 13 KB | Visualizations |
| insights.js | 703 | 26 KB | Insights |
| export.js | 428 | 18 KB | Export |
| **Total Code** | **2,887** | **109 KB** | - |

---

**Architecture designed for:**
- ✅ Simplicity
- ✅ Maintainability
- ✅ Extensibility
- ✅ Performance
- ✅ Accessibility

---

*Last Updated: 2024-10-27*
