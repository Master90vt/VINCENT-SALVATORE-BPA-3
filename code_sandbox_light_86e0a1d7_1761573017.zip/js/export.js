/**
 * Business Productivity Analyzer - Export Module
 * Handles CSV export, PDF printing, and report generation
 */

/**
 * Export data to CSV
 */
function exportToCSV() {
    if (!AppState.resultsA || !AppState.resultsB) {
        alert('Please calculate results first before exporting.');
        return;
    }
    
    const metricsA = AppState.resultsA;
    const metricsB = AppState.resultsB;
    const cpi = calculateCPI(metricsA, metricsB);
    
    // Build CSV content
    let csv = 'VINCENT SALVATORE Business Productivity Analyzer - Comparative Analysis Report\n';
    csv += `Generated: ${new Date().toISOString()}\n\n`;
    
    // Company inputs
    csv += 'COMPANY INPUTS\n';
    csv += `Metric,${metricsA.companyName},${metricsB.companyName}\n`;
    csv += `Revenue,${metricsA.revenue},${metricsB.revenue}\n`;
    csv += `Profit,${metricsA.profit},${metricsB.profit}\n`;
    csv += `Employees,${metricsA.employees},${metricsB.employees}\n`;
    csv += `Total Hours,${metricsA.hours},${metricsB.hours}\n`;
    csv += `Period,${getPeriodLabel(metricsA.period)},${getPeriodLabel(metricsB.period)}\n`;
    csv += `COGS,${metricsA.cogs},${metricsB.cogs}\n`;
    csv += `Operating Costs,${metricsA.opex},${metricsB.opex}\n`;
    csv += `Notes,"${metricsA.notes}","${metricsB.notes}"\n\n`;
    
    // Calculated metrics
    csv += 'CALCULATED METRICS\n';
    csv += `Metric,${metricsA.companyName},${metricsB.companyName},Winner,Delta %\n`;
    
    const metrics = [
        { name: 'Revenue per Hour (RPH)', keyA: 'rph', keyB: 'rph' },
        { name: 'Profit per Hour (PPH)', keyA: 'pph', keyB: 'pph' },
        { name: 'Revenue per Employee (RPE)', keyA: 'rpe', keyB: 'rpe' },
        { name: 'Profit per Employee (PPE)', keyA: 'ppe', keyB: 'ppe' },
        { name: 'Profit Margin', keyA: 'profitMargin', keyB: 'profitMargin' },
        { name: 'Labor Intensity (hrs/employee)', keyA: 'laborIntensity', keyB: 'laborIntensity' }
    ];
    
    metrics.forEach(metric => {
        const valueA = metricsA[metric.keyA];
        const valueB = metricsB[metric.keyB];
        const winner = valueA > valueB ? metricsA.companyName : (valueB > valueA ? metricsB.companyName : 'Tie');
        const delta = ((valueB - valueA) / valueA * 100).toFixed(2);
        
        csv += `${metric.name},${valueA.toFixed(2)},${valueB.toFixed(2)},${winner},${delta}\n`;
    });
    
    csv += '\n';
    
    // Annualized metrics
    csv += 'ANNUALIZED METRICS\n';
    csv += `Metric,${metricsA.companyName},${metricsB.companyName}\n`;
    csv += `Annualized Revenue per Hour,${metricsA.annualizedRPH.toFixed(2)},${metricsB.annualizedRPH.toFixed(2)}\n`;
    csv += `Annualized Profit per Hour,${metricsA.annualizedPPH.toFixed(2)},${metricsB.annualizedPPH.toFixed(2)}\n`;
    csv += `Annualized Revenue per Employee,${metricsA.annualizedRPE.toFixed(2)},${metricsB.annualizedRPE.toFixed(2)}\n`;
    csv += `Annualized Profit per Employee,${metricsA.annualizedPPE.toFixed(2)},${metricsB.annualizedPPE.toFixed(2)}\n\n`;
    
    // GVA if available
    if (metricsA.gva !== null || metricsB.gva !== null) {
        csv += 'GROSS VALUE ADDED (GVA)\n';
        csv += 'Metric,Company A,Company B\n';
        csv += `GVA,${metricsA.gva || 0},${metricsB.gva || 0}\n`;
        csv += `GVA per Employee,${metricsA.gvaPerEmployee || 0},${metricsB.gvaPerEmployee || 0}\n`;
        csv += `GVA per Hour,${metricsA.gvaPerHour || 0},${metricsB.gvaPerHour || 0}\n\n`;
    }
    
    // CPI
    csv += 'COMPOSITE PRODUCTIVITY INDEX (CPI)\n';
    csv += 'Component,Weight,Company A,Company B\n';
    csv += `Revenue per Hour,${AppState.cpiWeights.rph},${cpi.zScores.rph.A.toFixed(3)},${cpi.zScores.rph.B.toFixed(3)}\n`;
    csv += `Revenue per Employee,${AppState.cpiWeights.rpe},${cpi.zScores.rpe.A.toFixed(3)},${cpi.zScores.rpe.B.toFixed(3)}\n`;
    csv += `Profit per Hour,${AppState.cpiWeights.pph},${cpi.zScores.pph.A.toFixed(3)},${cpi.zScores.pph.B.toFixed(3)}\n`;
    csv += `Profit per Employee,${AppState.cpiWeights.ppe},${cpi.zScores.ppe.A.toFixed(3)},${cpi.zScores.ppe.B.toFixed(3)}\n`;
    csv += `\nOverall CPI (normalized 0-100),${cpi.normalized.A.toFixed(2)},${cpi.normalized.B.toFixed(2)}\n`;
    csv += `Winner,${cpi.winner === 'Tie' ? 'Tie' : 'Company ' + cpi.winner}\n`;
    csv += `CPI Gap,${cpi.gap.toFixed(2)} points\n\n`;
    
    // Warnings
    if (metricsA.warnings.length > 0 || metricsB.warnings.length > 0) {
        csv += 'WARNINGS & FLAGS\n';
        if (metricsA.warnings.length > 0) {
            csv += 'Company A:\n';
            metricsA.warnings.forEach(w => csv += `"${w.message}"\n`);
        }
        if (metricsB.warnings.length > 0) {
            csv += 'Company B:\n';
            metricsB.warnings.forEach(w => csv += `"${w.message}"\n`);
        }
        csv += '\n';
    }
    
    // Download CSV
    downloadFile(csv, 'productivity-analysis-report.csv', 'text/csv');
    
    console.log('✅ CSV exported successfully');
}

/**
 * Print to PDF (using browser print)
 */
function printToPDF() {
    if (!AppState.resultsA || !AppState.resultsB) {
        alert('Please calculate results first before printing.');
        return;
    }
    
    window.print();
}

/**
 * Download full report (comprehensive HTML export)
 */
function downloadFullReport() {
    if (!AppState.resultsA || !AppState.resultsB) {
        alert('Please calculate results first before downloading report.');
        return;
    }
    
    const metricsA = AppState.resultsA;
    const metricsB = AppState.resultsB;
    const cpi = calculateCPI(metricsA, metricsB);
    
    // Generate comprehensive HTML report
    let html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VINCENT SALVATORE Business Productivity Analysis Report</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            line-height: 1.6; 
            color: #333; 
            max-width: 1200px; 
            margin: 0 auto; 
            padding: 40px 20px; 
            background: #f5f5f5;
        }
        .header { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white; 
            padding: 40px; 
            border-radius: 10px; 
            margin-bottom: 30px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .header h1 { font-size: 32px; margin-bottom: 10px; }
        .header p { font-size: 14px; opacity: 0.9; }
        .section { 
            background: white; 
            padding: 30px; 
            margin-bottom: 20px; 
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .section h2 { 
            font-size: 24px; 
            margin-bottom: 20px; 
            color: #667eea; 
            border-bottom: 3px solid #667eea; 
            padding-bottom: 10px;
        }
        .section h3 { 
            font-size: 18px; 
            margin: 20px 0 10px 0; 
            color: #764ba2;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin: 20px 0;
        }
        th, td { 
            padding: 12px; 
            text-align: left; 
            border-bottom: 1px solid #ddd;
        }
        th { 
            background: #f8f9fa; 
            font-weight: 600; 
            color: #667eea;
        }
        .metric-card { 
            display: inline-block; 
            background: #f8f9fa; 
            padding: 15px 20px; 
            margin: 10px 10px 10px 0; 
            border-radius: 8px; 
            border-left: 4px solid #667eea;
        }
        .metric-card strong { 
            display: block; 
            font-size: 24px; 
            color: #667eea; 
            margin-bottom: 5px;
        }
        .metric-card span { 
            font-size: 12px; 
            color: #666;
        }
        .winner { 
            color: #10b981; 
            font-weight: bold;
        }
        .insight { 
            background: #f0f9ff; 
            border-left: 4px solid #3b82f6; 
            padding: 15px; 
            margin: 15px 0;
            border-radius: 5px;
        }
        .recommendation { 
            background: #f0fdf4; 
            border-left: 4px solid #10b981; 
            padding: 15px; 
            margin: 15px 0;
            border-radius: 5px;
        }
        .recommendation strong { color: #059669; }
        .footer { 
            text-align: center; 
            margin-top: 40px; 
            padding-top: 20px; 
            border-top: 2px solid #ddd; 
            color: #999; 
            font-size: 12px;
        }
        @media print {
            body { background: white; }
            .section { page-break-inside: avoid; box-shadow: none; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>📊 VINCENT SALVATORE Business Productivity Analysis Report</h1>
        <p>Comparative Analysis: ${metricsA.companyName} vs ${metricsB.companyName}</p>
        <p>Generated: ${new Date().toLocaleString()}</p>
    </div>`;
    
    // Executive Summary
    html += `
    <div class="section">
        <h2>Executive Summary</h2>
        <div class="metric-card">
            <strong>${cpi.winner === 'Tie' ? 'Tie' : 'Company ' + cpi.winner}</strong>
            <span>Overall Winner by CPI</span>
        </div>
        <div class="metric-card">
            <strong>${cpi.gap.toFixed(1)} points</strong>
            <span>CPI Gap</span>
        </div>
        <div class="metric-card">
            <strong>${getPeriodLabel(metricsA.period)}</strong>
            <span>Analysis Period</span>
        </div>
    </div>`;
    
    // Company Inputs
    html += `
    <div class="section">
        <h2>Company Inputs</h2>
        <table>
            <thead>
                <tr><th>Metric</th><th>${metricsA.companyName}</th><th>${metricsB.companyName}</th></tr>
            </thead>
            <tbody>
                <tr><td>Revenue</td><td>${formatCurrency(metricsA.revenue, 0)}</td><td>${formatCurrency(metricsB.revenue, 0)}</td></tr>
                <tr><td>Profit</td><td>${formatCurrency(metricsA.profit, 0)}</td><td>${formatCurrency(metricsB.profit, 0)}</td></tr>
                <tr><td>Employees</td><td>${metricsA.employees}</td><td>${metricsB.employees}</td></tr>
                <tr><td>Total Hours</td><td>${formatNumber(metricsA.hours, 0)}</td><td>${formatNumber(metricsB.hours, 0)}</td></tr>
                <tr><td>Period</td><td>${getPeriodLabel(metricsA.period)}</td><td>${getPeriodLabel(metricsB.period)}</td></tr>
            </tbody>
        </table>
    </div>`;
    
    // Key Metrics
    html += `
    <div class="section">
        <h2>Key Productivity Metrics</h2>
        <table>
            <thead>
                <tr><th>Metric</th><th>${metricsA.companyName}</th><th>${metricsB.companyName}</th><th>Winner</th><th>Delta</th></tr>
            </thead>
            <tbody>
                <tr>
                    <td>Revenue per Hour</td>
                    <td>${formatCurrency(metricsA.rph, 2)}</td>
                    <td>${formatCurrency(metricsB.rph, 2)}</td>
                    <td class="winner">${metricsA.rph > metricsB.rph ? metricsA.companyName : metricsB.companyName}</td>
                    <td>${((metricsB.rph - metricsA.rph) / metricsA.rph * 100).toFixed(1)}%</td>
                </tr>
                <tr>
                    <td>Profit per Hour</td>
                    <td>${formatCurrency(metricsA.pph, 2)}</td>
                    <td>${formatCurrency(metricsB.pph, 2)}</td>
                    <td class="winner">${metricsA.pph > metricsB.pph ? metricsA.companyName : metricsB.companyName}</td>
                    <td>${((metricsB.pph - metricsA.pph) / metricsA.pph * 100).toFixed(1)}%</td>
                </tr>
                <tr>
                    <td>Revenue per Employee</td>
                    <td>${formatCurrency(metricsA.rpe, 0)}</td>
                    <td>${formatCurrency(metricsB.rpe, 0)}</td>
                    <td class="winner">${metricsA.rpe > metricsB.rpe ? metricsA.companyName : metricsB.companyName}</td>
                    <td>${((metricsB.rpe - metricsA.rpe) / metricsA.rpe * 100).toFixed(1)}%</td>
                </tr>
                <tr>
                    <td>Profit per Employee</td>
                    <td>${formatCurrency(metricsA.ppe, 0)}</td>
                    <td>${formatCurrency(metricsB.ppe, 0)}</td>
                    <td class="winner">${metricsA.ppe > metricsB.ppe ? metricsA.companyName : metricsB.companyName}</td>
                    <td>${((metricsB.ppe - metricsA.ppe) / metricsA.ppe * 100).toFixed(1)}%</td>
                </tr>
                <tr>
                    <td>Profit Margin</td>
                    <td>${formatPercent(metricsA.profitMargin, 1)}</td>
                    <td>${formatPercent(metricsB.profitMargin, 1)}</td>
                    <td class="winner">${metricsA.profitMargin > metricsB.profitMargin ? metricsA.companyName : metricsB.companyName}</td>
                    <td>${((metricsB.profitMargin - metricsA.profitMargin) / metricsA.profitMargin * 100).toFixed(1)}%</td>
                </tr>
            </tbody>
        </table>
    </div>`;
    
    // CPI
    html += `
    <div class="section">
        <h2>Composite Productivity Index (CPI)</h2>
        <p><strong>Winner:</strong> <span class="winner">${cpi.winner === 'Tie' ? 'Tie' : 'Company ' + cpi.winner}</span> | <strong>Gap:</strong> ${cpi.gap.toFixed(1)} points</p>
        <h3>Component Weights</h3>
        <ul>
            <li>Revenue per Hour: ${(AppState.cpiWeights.rph * 100).toFixed(0)}%</li>
            <li>Revenue per Employee: ${(AppState.cpiWeights.rpe * 100).toFixed(0)}%</li>
            <li>Profit per Hour: ${(AppState.cpiWeights.pph * 100).toFixed(0)}%</li>
            <li>Profit per Employee: ${(AppState.cpiWeights.ppe * 100).toFixed(0)}%</li>
        </ul>
        <h3>Normalized Scores (0-100)</h3>
        <div class="metric-card">
            <strong>${cpi.normalized.A.toFixed(1)}</strong>
            <span>Company A CPI Score</span>
        </div>
        <div class="metric-card">
            <strong>${cpi.normalized.B.toFixed(1)}</strong>
            <span>Company B CPI Score</span>
        </div>
    </div>`;
    
    // Add insights (simplified for report)
    html += `
    <div class="section">
        <h2>Key Insights</h2>
        <div class="insight">
            <strong>Overall Productivity:</strong> Company ${cpi.winner} demonstrates superior overall productivity, driven primarily by ${findBestMetric()} performance.
        </div>
        <div class="insight">
            <strong>Time Leverage:</strong> Revenue per hour comparison shows ${metricsA.rph > metricsB.rph ? 'Company A' : 'Company B'} generates ${formatCurrency(Math.max(metricsA.rph, metricsB.rph), 2)}/hr vs ${formatCurrency(Math.min(metricsA.rph, metricsB.rph), 2)}/hr.
        </div>
        <div class="insight">
            <strong>Human Capital:</strong> ${metricsA.rpe > metricsB.rpe ? 'Company A' : 'Company B'} achieves higher revenue per employee at ${formatCurrency(Math.max(metricsA.rpe, metricsB.rpe), 0)} vs ${formatCurrency(Math.min(metricsA.rpe, metricsB.rpe), 0)}.
        </div>
    </div>`;
    
    // Footer
    html += `
    <div class="footer">
        <p>VINCENT SALVATORE Business Productivity Analyzer | Generated ${new Date().toLocaleDateString()}</p>
        <p>This report provides comparative productivity analysis for strategic decision-making.</p>
    </div>
</body>
</html>`;
    
    // Download HTML report
    downloadFile(html, 'productivity-analysis-full-report.html', 'text/html');
    
    console.log('✅ Full report downloaded successfully');
}

/**
 * Copy insights to clipboard
 */
function copyInsightsToClipboard() {
    const insightsContainer = document.getElementById('insightsContent');
    
    if (!insightsContainer) {
        alert('No insights available to copy.');
        return;
    }
    
    // Extract text content
    let text = 'VINCENT SALVATORE BUSINESS PRODUCTIVITY ANALYSIS - KEY INSIGHTS\n';
    text += `Generated: ${new Date().toLocaleString()}\n`;
    text += '='.repeat(60) + '\n\n';
    
    const insights = insightsContainer.querySelectorAll('.insight-card');
    insights.forEach((insight, i) => {
        const title = insight.querySelector('h4')?.textContent || '';
        const content = insight.querySelector('p')?.textContent || '';
        
        text += `${i + 1}. ${title}\n`;
        text += `${content}\n\n`;
    });
    
    text += '='.repeat(60) + '\n';
    text += 'End of Insights Report\n';
    
    // Copy to clipboard
    navigator.clipboard.writeText(text).then(() => {
        // Show success message
        const button = document.getElementById('copyInsights');
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-check mr-2"></i>Copied!';
        button.classList.remove('bg-gray-500', 'hover:bg-gray-600');
        button.classList.add('bg-green-500', 'hover:bg-green-600');
        
        setTimeout(() => {
            button.innerHTML = originalText;
            button.classList.remove('bg-green-500', 'hover:bg-green-600');
            button.classList.add('bg-gray-500', 'hover:bg-gray-600');
        }, 2000);
    }).catch(err => {
        console.error('Failed to copy:', err);
        alert('Failed to copy to clipboard. Please try again.');
    });
}

/**
 * Utility function to download a file
 */
function downloadFile(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}
