/**
 * Business Productivity Analyzer - Main Application
 * Handles UI initialization, form generation, theme toggle, and state management
 */

// Global state
const AppState = {
    companyA: {},
    companyB: {},
    resultsA: null,
    resultsB: null,
    cpiWeights: {
        rph: 0.35,
        rpe: 0.25,
        pph: 0.25,
        ppe: 0.15
    },
    charts: {},
    darkMode: true
};

// Form field definitions
const formFields = [
    {
        name: 'companyName',
        label: 'Company Name',
        type: 'text',
        required: false,
        icon: 'fa-building',
        help: 'Name or identifier for this company (optional)'
    },
    {
        name: 'revenue',
        label: 'Revenue',
        type: 'number',
        required: true,
        min: 0,
        step: 0.01,
        icon: 'fa-dollar-sign',
        help: 'Total revenue for the period'
    },
    {
        name: 'profit',
        label: 'Profit',
        type: 'number',
        required: false,
        min: 0,
        step: 0.01,
        icon: 'fa-chart-line',
        help: 'Net profit (leave 0 if not available)'
    },
    {
        name: 'employees',
        label: 'Number of Employees',
        type: 'number',
        required: true,
        min: 1,
        step: 1,
        icon: 'fa-users',
        help: 'Total number of employees'
    },
    {
        name: 'hours',
        label: 'Total Hours Worked',
        type: 'number',
        required: true,
        min: 1,
        step: 0.1,
        icon: 'fa-clock',
        help: 'Total labor hours in the period'
    },
    {
        name: 'period',
        label: 'Reference Period',
        type: 'select',
        required: true,
        icon: 'fa-calendar',
        help: 'Time period for the data',
        options: [
            { value: 'week', label: '1 Week', factor: 52 },
            { value: 'month', label: '1 Month', factor: 12 },
            { value: 'quarter', label: '3 Months (Quarter)', factor: 4 },
            { value: 'half', label: '6 Months (Half Year)', factor: 2 },
            { value: 'year', label: '1 Year', factor: 1 }
        ]
    },
    {
        name: 'cogs',
        label: 'COGS (Cost of Goods Sold)',
        type: 'number',
        required: false,
        min: 0,
        step: 0.01,
        icon: 'fa-box',
        help: 'Optional: Cost of goods sold'
    },
    {
        name: 'opex',
        label: 'Other Operating Costs',
        type: 'number',
        required: false,
        min: 0,
        step: 0.01,
        icon: 'fa-receipt',
        help: 'Optional: Other operating expenses'
    },
    {
        name: 'notes',
        label: 'Notes / Tags',
        type: 'textarea',
        required: false,
        icon: 'fa-tag',
        help: 'Optional: e.g., "seasonal", "one-off project"'
    }
];

/**
 * Initialize the application
 */
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 VINCENT SALVATORE Business Productivity Analyzer initializing...');
    
    // Initialize theme
    initTheme();
    
    // Generate forms
    generateForm('formA', 'A');
    generateForm('formB', 'B');
    
    // Attach event listeners
    attachEventListeners();
    
    // Check for saved state
    checkSavedState();
    
    console.log('✅ Application ready');
});

/**
 * Generate form fields dynamically
 */
function generateForm(formId, company) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    formFields.forEach(field => {
        const fieldId = `${field.name}_${company}`;
        const fieldGroup = document.createElement('div');
        fieldGroup.className = 'form-group';
        
        let fieldHTML = `
            <label for="${fieldId}" class="block text-sm font-semibold mb-2 text-gray-700 dark:text-gray-300">
                <i class="fas ${field.icon} mr-2 text-gray-500"></i>
                ${field.label}
                ${field.required ? '<span class="text-red-500">*</span>' : '<span class="text-gray-400 text-xs">(Optional)</span>'}
            </label>
        `;
        
        if (field.type === 'select') {
            fieldHTML += `
                <select 
                    id="${fieldId}" 
                    name="${field.name}"
                    ${field.required ? 'required' : ''}
                    class="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                >
                    <option value="">Select period...</option>
                    ${field.options.map(opt => `<option value="${opt.value}" data-factor="${opt.factor}">${opt.label}</option>`).join('')}
                </select>
            `;
        } else if (field.type === 'textarea') {
            fieldHTML += `
                <textarea 
                    id="${fieldId}" 
                    name="${field.name}"
                    rows="3"
                    placeholder="${field.help}"
                    class="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
                ></textarea>
            `;
        } else {
            fieldHTML += `
                <input 
                    type="${field.type}" 
                    id="${fieldId}" 
                    name="${field.name}"
                    ${field.required ? 'required' : ''}
                    ${field.min !== undefined ? `min="${field.min}"` : ''}
                    ${field.step ? `step="${field.step}"` : ''}
                    ${field.type === 'number' ? 'value="0"' : ''}
                    placeholder="${field.help}"
                    class="w-full px-4 py-3 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                />
            `;
        }
        
        if (field.help) {
            fieldHTML += `<p class="mt-1 text-xs text-gray-500 dark:text-gray-400"><i class="fas fa-info-circle mr-1"></i>${field.help}</p>`;
        }
        
        fieldGroup.innerHTML = fieldHTML;
        form.appendChild(fieldGroup);
    });
}

/**
 * Attach all event listeners
 */
function attachEventListeners() {
    // Theme toggle
    document.getElementById('themeToggle')?.addEventListener('click', toggleTheme);
    
    // Calculate button
    document.getElementById('calculateBtn')?.addEventListener('click', handleCalculate);
    
    // Load example
    document.getElementById('loadExample')?.addEventListener('click', loadExampleData);
    
    // Clear form
    document.getElementById('clearForm')?.addEventListener('click', clearAllForms);
    
    // Save/Load scenarios
    document.getElementById('saveScenario')?.addEventListener('click', saveScenario);
    document.getElementById('loadScenario')?.addEventListener('click', loadScenario);
    
    // Export actions
    document.getElementById('exportCsv')?.addEventListener('click', exportToCSV);
    document.getElementById('printPdf')?.addEventListener('click', printToPDF);
    document.getElementById('exportReport')?.addEventListener('click', downloadFullReport);
    document.getElementById('copyInsights')?.addEventListener('click', copyInsightsToClipboard);
}

/**
 * Handle calculation button click
 */
function handleCalculate() {
    console.log('📊 Starting calculation...');
    
    // Show loading
    showLoading(true);
    
    // Validate and collect data
    const dataA = collectFormData('A');
    const dataB = collectFormData('B');
    
    if (!dataA || !dataB) {
        showLoading(false);
        return;
    }
    
    // Validate data
    const validationA = validateData(dataA, 'Company A');
    const validationB = validateData(dataB, 'Company B');
    
    if (!validationA.valid || !validationB.valid) {
        showLoading(false);
        alert(`Validation errors:\n${validationA.errors.join('\n')}\n${validationB.errors.join('\n')}`);
        return;
    }
    
    // Store in state
    AppState.companyA = dataA;
    AppState.companyB = dataB;
    
    // Calculate metrics
    setTimeout(() => {
        AppState.resultsA = calculateMetrics(dataA);
        AppState.resultsB = calculateMetrics(dataB);
        
        console.log('Results A:', AppState.resultsA);
        console.log('Results B:', AppState.resultsB);
        
        // Update UI
        updateSummaryRibbon();
        generateWeightControls();
        generateComparisonCards();
        renderCharts();
        generateInsights();
        generateRecommendations();
        
        // Show results
        document.getElementById('resultsSection').classList.remove('hidden');
        document.getElementById('insightsSection').classList.remove('hidden');
        document.getElementById('summaryRibbon').classList.remove('hidden');
        
        // Scroll to results
        document.getElementById('resultsSection').scrollIntoView({ behavior: 'smooth', block: 'start' });
        
        showLoading(false);
        console.log('✅ Calculation complete');
    }, 500);
}

/**
 * Collect form data for a company
 */
function collectFormData(company) {
    const data = {};
    
    formFields.forEach(field => {
        const fieldId = `${field.name}_${company}`;
        const element = document.getElementById(fieldId);
        
        if (!element) return;
        
        if (field.type === 'number') {
            data[field.name] = parseFloat(element.value) || 0;
        } else if (field.type === 'select') {
            data[field.name] = element.value;
            const selectedOption = element.options[element.selectedIndex];
            data.periodFactor = parseFloat(selectedOption.dataset.factor) || 1;
        } else {
            data[field.name] = element.value;
        }
    });
    
    data.company = company;
    return data;
}

/**
 * Validate company data
 */
function validateData(data, companyName) {
    const errors = [];
    
    // Required fields
    if (!data.revenue || data.revenue <= 0) {
        errors.push(`${companyName}: Revenue must be greater than 0`);
    }
    
    if (!data.employees || data.employees < 1) {
        errors.push(`${companyName}: Number of employees must be at least 1`);
    }
    
    if (!data.hours || data.hours <= 0) {
        errors.push(`${companyName}: Total hours must be greater than 0`);
    }
    
    if (!data.period) {
        errors.push(`${companyName}: Please select a reference period`);
    }
    
    // Business logic validation
    if (data.profit > data.revenue) {
        errors.push(`${companyName}: Profit cannot exceed revenue`);
    }
    
    if (data.cogs > data.revenue) {
        errors.push(`${companyName}: COGS cannot exceed revenue`);
    }
    
    // Outlier warnings (not blocking)
    if (data.profit / data.revenue > 0.8) {
        console.warn(`⚠️ ${companyName}: Profit margin > 80% - this is unusually high`);
    }
    
    const hoursPerEmployee = data.hours / data.employees;
    const maxHoursPerPeriod = {
        'week': 80,
        'month': 320,
        'quarter': 960,
        'half': 1920,
        'year': 3840
    };
    
    if (hoursPerEmployee > maxHoursPerPeriod[data.period]) {
        console.warn(`⚠️ ${companyName}: Hours per employee (${hoursPerEmployee.toFixed(0)}) seems very high for the period`);
    }
    
    return {
        valid: errors.length === 0,
        errors: errors
    };
}

/**
 * Load example data
 */
function loadExampleData() {
    // Company A - Traditional business
    document.getElementById('companyName_A').value = 'Retail Store Inc.';
    document.getElementById('revenue_A').value = 50000;
    document.getElementById('profit_A').value = 5000;
    document.getElementById('employees_A').value = 10;
    document.getElementById('hours_A').value = 1500;
    document.getElementById('period_A').value = 'month';
    document.getElementById('cogs_A').value = 25000;
    document.getElementById('opex_A').value = 20000;
    document.getElementById('notes_A').value = 'Traditional retail business';
    
    // Company B - High-efficiency business
    document.getElementById('companyName_B').value = 'Digital Consultancy LLC';
    document.getElementById('revenue_B').value = 10000;
    document.getElementById('profit_B').value = 4000;
    document.getElementById('employees_B').value = 1;
    document.getElementById('hours_B').value = 10;
    document.getElementById('period_B').value = 'month';
    document.getElementById('cogs_B').value = 3000;
    document.getElementById('opex_B').value = 3000;
    document.getElementById('notes_B').value = 'High-leverage digital consultancy';
    
    alert('✅ Example data loaded! Click "Calculate & Analyze Productivity" to see results.');
}

/**
 * Clear all forms
 */
function clearAllForms() {
    if (!confirm('Are you sure you want to clear all data?')) return;
    
    document.getElementById('formA').reset();
    document.getElementById('formB').reset();
    
    // Hide results
    document.getElementById('resultsSection').classList.add('hidden');
    document.getElementById('insightsSection').classList.add('hidden');
    document.getElementById('summaryRibbon').classList.add('hidden');
    
    // Clear state
    AppState.companyA = {};
    AppState.companyB = {};
    AppState.resultsA = null;
    AppState.resultsB = null;
}

/**
 * Theme management
 */
function initTheme() {
    const savedTheme = localStorage.getItem('theme') || 'dark';
    AppState.darkMode = savedTheme === 'dark';
    
    if (AppState.darkMode) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }
}

function toggleTheme() {
    AppState.darkMode = !AppState.darkMode;
    
    if (AppState.darkMode) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('theme', 'dark');
    } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('theme', 'light');
    }
    
    // Re-render charts with new theme
    if (AppState.resultsA && AppState.resultsB) {
        renderCharts();
    }
}

/**
 * Save scenario to localStorage
 */
function saveScenario() {
    const scenarioName = prompt('Enter a name for this scenario:');
    if (!scenarioName) return;
    
    const scenarios = JSON.parse(localStorage.getItem('scenarios') || '{}');
    scenarios[scenarioName] = {
        companyA: AppState.companyA,
        companyB: AppState.companyB,
        weights: AppState.cpiWeights,
        timestamp: new Date().toISOString()
    };
    
    localStorage.setItem('scenarios', JSON.stringify(scenarios));
    alert(`✅ Scenario "${scenarioName}" saved successfully!`);
}

/**
 * Load scenario from localStorage
 */
function loadScenario() {
    const scenarios = JSON.parse(localStorage.getItem('scenarios') || '{}');
    const scenarioNames = Object.keys(scenarios);
    
    if (scenarioNames.length === 0) {
        alert('No saved scenarios found. Save a scenario first!');
        return;
    }
    
    const scenarioList = scenarioNames.map((name, i) => `${i + 1}. ${name}`).join('\n');
    const selection = prompt(`Select a scenario to load:\n\n${scenarioList}\n\nEnter the number:`);
    
    if (!selection) return;
    
    const index = parseInt(selection) - 1;
    if (index < 0 || index >= scenarioNames.length) {
        alert('Invalid selection');
        return;
    }
    
    const scenarioName = scenarioNames[index];
    const scenario = scenarios[scenarioName];
    
    // Populate forms
    Object.keys(scenario.companyA).forEach(key => {
        const element = document.getElementById(`${key}_A`);
        if (element) element.value = scenario.companyA[key];
    });
    
    Object.keys(scenario.companyB).forEach(key => {
        const element = document.getElementById(`${key}_B`);
        if (element) element.value = scenario.companyB[key];
    });
    
    if (scenario.weights) {
        AppState.cpiWeights = scenario.weights;
    }
    
    alert(`✅ Scenario "${scenarioName}" loaded successfully!`);
}

/**
 * Check for saved state on load
 */
function checkSavedState() {
    const scenarios = JSON.parse(localStorage.getItem('scenarios') || '{}');
    const scenarioCount = Object.keys(scenarios).length;
    
    if (scenarioCount > 0) {
        console.log(`💾 Found ${scenarioCount} saved scenario(s)`);
    }
}

/**
 * Show/hide loading overlay
 */
function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.toggle('hidden', !show);
    }
}

/**
 * Utility: Format currency
 */
function formatCurrency(value, decimals = 0) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    }).format(value);
}

/**
 * Utility: Format number
 */
function formatNumber(value, decimals = 2) {
    return new Intl.NumberFormat('en-US', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    }).format(value);
}

/**
 * Utility: Format percentage
 */
function formatPercent(value, decimals = 1) {
    return `${(value * 100).toFixed(decimals)}%`;
}

/**
 * Utility: Get period label
 */
function getPeriodLabel(period) {
    const labels = {
        'week': '1 Week',
        'month': '1 Month',
        'quarter': '3 Months',
        'half': '6 Months',
        'year': '1 Year'
    };
    return labels[period] || period;
}
