/**
 * Business Productivity Analyzer - Insights & Recommendations Module
 * Generates executive insights and actionable recommendations
 */

/**
 * Generate executive insights
 */
function generateInsights() {
    const container = document.getElementById('insightsContent');
    if (!container) return;
    
    const metricsA = AppState.resultsA;
    const metricsB = AppState.resultsB;
    const cpi = calculateCPI(metricsA, metricsB);
    
    const insights = [];
    
    // 1. Overall Winner and Why
    insights.push(generateWinnerInsight(metricsA, metricsB, cpi));
    
    // 2. Time Leverage Analysis
    insights.push(generateTimeLeverageInsight(metricsA, metricsB));
    
    // 3. Human Capital Efficiency
    insights.push(generateHumanCapitalInsight(metricsA, metricsB));
    
    // 4. Profit Architecture
    insights.push(generateProfitArchitectureInsight(metricsA, metricsB));
    
    // 5. Weight Sensitivity Analysis
    insights.push(generateWeightSensitivityInsight(metricsA, metricsB, cpi));
    
    // 6. Risk Flags
    const riskInsight = generateRiskFlagsInsight(metricsA, metricsB);
    if (riskInsight) {
        insights.push(riskInsight);
    }
    
    // Render insights
    container.innerHTML = insights.map((insight, i) => `
        <div class="insight-card bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-700 dark:to-gray-700 rounded-lg p-5 border-l-4 border-${insight.color || 'blue'}-500">
            <div class="flex items-start gap-3">
                <div class="flex-shrink-0 mt-1">
                    <i class="fas ${insight.icon} text-${insight.color || 'blue'}-600 text-xl"></i>
                </div>
                <div class="flex-1">
                    <h4 class="font-bold text-lg mb-2 text-gray-900 dark:text-gray-100">${insight.title}</h4>
                    <p class="text-gray-700 dark:text-gray-300 leading-relaxed">${insight.content}</p>
                    ${insight.details ? `<ul class="mt-3 space-y-1 text-sm text-gray-600 dark:text-gray-400">
                        ${insight.details.map(d => `<li><i class="fas fa-arrow-right mr-2"></i>${d}</li>`).join('')}
                    </ul>` : ''}
                </div>
            </div>
        </div>
    `).join('');
}

/**
 * Generate winner insight
 */
function generateWinnerInsight(metricsA, metricsB, cpi) {
    const winner = cpi.winner;
    const loser = winner === 'A' ? 'B' : 'A';
    const winnerMetrics = winner === 'A' ? metricsA : metricsB;
    const loserMetrics = winner === 'A' ? metricsB : metricsA;
    
    if (winner === 'Tie') {
        return {
            title: '🤝 Productivity Parity',
            icon: 'fa-balance-scale',
            color: 'gray',
            content: `Both companies show nearly identical overall productivity based on the current CPI weights. The difference is less than ${cpi.gap.toFixed(1)} points, indicating similar efficiency levels.`,
            details: [
                `Company A excels in: ${findTopMetrics(metricsA, metricsB).join(', ')}`,
                `Company B excels in: ${findTopMetrics(metricsB, metricsA).join(', ')}`,
                'Consider adjusting weights based on your strategic priorities to identify the better fit.'
            ]
        };
    }
    
    // Find top 3 metrics driving the gap
    const topMetrics = findTopMetricGaps(winnerMetrics, loserMetrics);
    
    const rphGap = ((winnerMetrics.rph - loserMetrics.rph) / loserMetrics.rph) * 100;
    const rpeGap = ((winnerMetrics.rpe - loserMetrics.rpe) / loserMetrics.rpe) * 100;
    const pphGap = ((winnerMetrics.pph - loserMetrics.pph) / loserMetrics.pph) * 100;
    
    let content = `<strong>Company ${winner}</strong> is significantly more productive, leading by <strong>${cpi.gap.toFixed(1)} CPI points</strong>. `;
    
    content += `The advantage is primarily driven by ${topMetrics.length} key areas: `;
    content += topMetrics.map(m => `<strong>${m.name}</strong> (${m.gap > 0 ? '+' : ''}${m.gap.toFixed(1)}%)`).join(', ');
    content += '.';
    
    return {
        title: `🏆 Company ${winner} Wins on Overall Productivity`,
        icon: 'fa-trophy',
        color: 'purple',
        content: content,
        details: [
            `Revenue per Hour: Company ${winner} generates ${formatCurrency(winnerMetrics.rph, 2)}/hr vs ${formatCurrency(loserMetrics.rph, 2)}/hr (${rphGap > 0 ? '+' : ''}${rphGap.toFixed(1)}%)`,
            `Revenue per Employee: ${formatCurrency(winnerMetrics.rpe, 0)} vs ${formatCurrency(loserMetrics.rpe, 0)} (${rpeGap > 0 ? '+' : ''}${rpeGap.toFixed(1)}%)`,
            `Profit per Hour: ${formatCurrency(winnerMetrics.pph, 2)}/hr vs ${formatCurrency(loserMetrics.pph, 2)}/hr (${pphGap > 0 ? '+' : ''}${pphGap.toFixed(1)}%)`
        ]
    };
}

/**
 * Generate time leverage insight
 */
function generateTimeLeverageInsight(metricsA, metricsB) {
    const rphRatio = metricsB.rph / metricsA.rph;
    const pphRatio = metricsB.pph / metricsA.pph;
    
    const betterRph = metricsA.rph > metricsB.rph ? 'A' : 'B';
    const betterPph = metricsA.pph > metricsB.pph ? 'A' : 'B';
    
    let content = '';
    
    if (Math.abs(rphRatio - 1) > 0.5) {
        // Significant difference
        if (rphRatio > 1) {
            content = `Company B generates <strong>${rphRatio.toFixed(1)}× more revenue per hour</strong> than Company A. `;
            content += `This suggests Company B has superior time leverage - possibly through automation, pricing power, or higher-value work. `;
        } else {
            content = `Company A generates <strong>${(1/rphRatio).toFixed(1)}× more revenue per hour</strong> than Company B. `;
            content += `Company A demonstrates better time utilization and throughput efficiency. `;
        }
    } else {
        content = `Both companies show similar revenue generation per hour (within ${Math.abs((rphRatio - 1) * 100).toFixed(0)}%). `;
    }
    
    if (Math.abs(pphRatio - 1) > 0.3) {
        const profitLeader = pphRatio > 1 ? 'B' : 'A';
        const profitRatio = pphRatio > 1 ? pphRatio : (1/pphRatio);
        content += `However, Company ${profitLeader} captures <strong>${profitRatio.toFixed(1)}× more profit per hour</strong>, indicating better cost control or margin management.`;
    }
    
    return {
        title: '⏱️ Time Leverage Analysis',
        icon: 'fa-clock',
        color: 'blue',
        content: content,
        details: [
            `Company A: ${formatCurrency(metricsA.rph, 2)}/hr revenue, ${formatCurrency(metricsA.pph, 2)}/hr profit`,
            `Company B: ${formatCurrency(metricsB.rph, 2)}/hr revenue, ${formatCurrency(metricsB.pph, 2)}/hr profit`,
            `Time is the ultimate non-renewable resource. The company with better RPH and PPH can scale faster with less labor.`
        ]
    };
}

/**
 * Generate human capital efficiency insight
 */
function generateHumanCapitalInsight(metricsA, metricsB) {
    const rpeRatio = metricsB.rpe / metricsA.rpe;
    const laborIntensityA = metricsA.laborIntensity;
    const laborIntensityB = metricsB.laborIntensity;
    
    let content = '';
    
    if (rpeRatio > 1.5) {
        content = `Company B achieves <strong>${rpeRatio.toFixed(1)}× higher revenue per employee</strong>. `;
        content += `This superior human capital efficiency could stem from: `;
        content += `better talent, more efficient processes, technology leverage, or a more scalable business model. `;
    } else if (rpeRatio < 0.67) {
        content = `Company A achieves <strong>${(1/rpeRatio).toFixed(1)}× higher revenue per employee</strong>. `;
        content += `Company A's workforce is more productive per head, suggesting better training, systems, or talent density. `;
    } else {
        content = `Both companies show comparable revenue per employee (within ${Math.abs((rpeRatio - 1) * 100).toFixed(0)}% of each other). `;
    }
    
    // Labor intensity analysis
    const intensityRatio = laborIntensityB / laborIntensityA;
    
    if (intensityRatio > 1.3) {
        content += `Company B employees work <strong>${intensityRatio.toFixed(1)}× more hours</strong> per person in this period, `;
        content += `which may indicate seasonality, project intensity, or potential burnout risk.`;
    } else if (intensityRatio < 0.77) {
        content += `Company A employees work <strong>${(1/intensityRatio).toFixed(1)}× more hours</strong> per person, `;
        content += `suggesting higher workload or less efficient time management.`;
    }
    
    return {
        title: '👥 Human Capital Efficiency',
        icon: 'fa-users',
        color: 'green',
        content: content,
        details: [
            `Company A: ${formatCurrency(metricsA.rpe, 0)} revenue/employee, ${laborIntensityA.toFixed(0)} hrs/employee`,
            `Company B: ${formatCurrency(metricsB.rpe, 0)} revenue/employee, ${laborIntensityB.toFixed(0)} hrs/employee`,
            `Profit per Employee: Company A ${formatCurrency(metricsA.ppe, 0)} vs Company B ${formatCurrency(metricsB.ppe, 0)}`
        ]
    };
}

/**
 * Generate profit architecture insight
 */
function generateProfitArchitectureInsight(metricsA, metricsB) {
    const marginA = metricsA.profitMargin;
    const marginB = metricsB.profitMargin;
    
    const highMargin = marginA > 0.3 || marginB > 0.3;
    const lowMargin = marginA < 0.1 || marginB < 0.1;
    
    let content = '';
    let suggestions = [];
    
    // High margin, low RPH scenario
    if (metricsA.profitMargin > 0.3 && metricsA.rph < metricsB.rph) {
        content += `Company A has a <strong>high profit margin (${formatPercent(marginA)})</strong> but lower revenue per hour. `;
        content += `This suggests premium pricing or low costs, but throughput could be improved. `;
        suggestions.push('Consider: process optimization, automation, or volume increases to leverage the strong margin');
    } else if (metricsB.profitMargin > 0.3 && metricsB.rph < metricsA.rph) {
        content += `Company B has a <strong>high profit margin (${formatPercent(marginB)})</strong> but lower revenue per hour. `;
        content += `Great unit economics, but throughput optimization could unlock significant growth. `;
        suggestions.push('Consider: scaling operations while maintaining the premium pricing model');
    }
    
    // Low margin, high RPH scenario
    if (metricsA.profitMargin < 0.15 && metricsA.rph > metricsB.rph) {
        content += `Company A has <strong>high throughput (${formatCurrency(metricsA.rph, 2)}/hr)</strong> but thin margins (${formatPercent(marginA)}). `;
        content += `This volume-based model needs cost discipline or pricing power to improve profitability. `;
        suggestions.push('Focus on: cost reduction, pricing optimization, or shifting to higher-margin offerings');
    } else if (metricsB.profitMargin < 0.15 && metricsB.rph > metricsA.rph) {
        content += `Company B has <strong>high throughput (${formatCurrency(metricsB.rph, 2)}/hr)</strong> but thin margins (${formatPercent(marginB)}). `;
        content += `Strong volume, but margin expansion is critical for sustainable profitability. `;
        suggestions.push('Priority: improve gross margins through better sourcing, pricing, or product mix');
    }
    
    // Balanced scenario
    if (!content) {
        const betterMargin = marginA > marginB ? 'A' : 'B';
        const betterMarginValue = Math.max(marginA, marginB);
        content = `Company ${betterMargin} demonstrates better profit architecture with a ${formatPercent(betterMarginValue)} margin. `;
        content += `Both companies should continuously optimize the balance between throughput (RPH) and profitability (margin).`;
    }
    
    return {
        title: '💰 Profit Architecture',
        icon: 'fa-chart-pie',
        color: 'orange',
        content: content,
        details: [
            `Company A: ${formatPercent(marginA)} margin, ${formatCurrency(metricsA.rph, 2)}/hr throughput`,
            `Company B: ${formatPercent(marginB)} margin, ${formatCurrency(metricsB.rph, 2)}/hr throughput`,
            ...suggestions
        ]
    };
}

/**
 * Generate weight sensitivity insight
 */
function generateWeightSensitivityInsight(metricsA, metricsB, currentCpi) {
    // Test alternative weight scenarios
    const scenarios = [
        { name: 'Throughput Priority', weights: { rph: 0.5, rpe: 0.2, pph: 0.2, ppe: 0.1 } },
        { name: 'Profit Focus', weights: { rph: 0.2, rpe: 0.1, pph: 0.5, ppe: 0.2 } },
        { name: 'Employee Efficiency', weights: { rph: 0.2, rpe: 0.3, pph: 0.2, ppe: 0.3 } }
    ];
    
    const results = scenarios.map(scenario => {
        const cpi = calculateCPI(metricsA, metricsB, scenario.weights);
        return {
            name: scenario.name,
            winner: cpi.winner
        };
    });
    
    const currentWinner = currentCpi.winner;
    const winsA = results.filter(r => r.winner === 'A').length;
    const winsB = results.filter(r => r.winner === 'B').length;
    const ties = results.filter(r => r.winner === 'Tie').length;
    
    let content = '';
    
    if (winsA > 0 && winsB > 0) {
        content = `<strong>The winner changes based on strategic priorities.</strong> Under current weights, Company ${currentWinner} leads. `;
        content += `However, testing alternative scenarios shows: `;
        content += results.map(r => `<strong>${r.name}</strong> → Company ${r.winner}`).join(', ');
        content += '. This suggests the companies have different strength profiles.';
    } else if (currentWinner !== 'Tie') {
        content = `<strong>Company ${currentWinner} is the clear winner</strong> across multiple weight scenarios, `;
        content += `indicating consistently superior productivity regardless of strategic focus.`;
    } else {
        content = `The companies show <strong>balanced productivity</strong> across different strategic priorities.`;
    }
    
    return {
        title: '🎯 Weight Sensitivity Analysis',
        icon: 'fa-balance-scale-right',
        color: 'indigo',
        content: content,
        details: [
            `Current winner: Company ${currentWinner} (CPI gap: ${currentCpi.gap.toFixed(1)} points)`,
            `Testing alternative weight scenarios helps identify which company fits your strategic priorities better`,
            `Use the weight sliders above to explore different scenarios interactively`
        ]
    };
}

/**
 * Generate risk flags insight
 */
function generateRiskFlagsInsight(metricsA, metricsB) {
    const allWarnings = [...metricsA.warnings, ...metricsB.warnings];
    
    if (allWarnings.length === 0) {
        return null;
    }
    
    const warningsByCompany = {
        A: metricsA.warnings.map(w => `Company A: ${w.message}`),
        B: metricsB.warnings.map(w => `Company B: ${w.message}`)
    };
    
    const allWarningMessages = [...warningsByCompany.A, ...warningsByCompany.B];
    
    let content = '<strong>Important considerations for interpretation:</strong> ';
    content += `${allWarnings.length} flag(s) detected that may affect the reliability or comparability of these results. `;
    content += 'Review the specific warnings below and adjust your analysis accordingly.';
    
    return {
        title: '⚠️ Risk Flags & Data Quality',
        icon: 'fa-exclamation-triangle',
        color: 'yellow',
        content: content,
        details: allWarningMessages
    };
}

/**
 * Find top metrics for a company
 */
function findTopMetrics(metricsA, metricsB) {
    const comparisons = [
        { name: 'RPH', better: metricsA.rph > metricsB.rph },
        { name: 'RPE', better: metricsA.rpe > metricsB.rpe },
        { name: 'PPH', better: metricsA.pph > metricsB.pph },
        { name: 'PPE', better: metricsA.ppe > metricsB.ppe },
        { name: 'Margin', better: metricsA.profitMargin > metricsB.profitMargin }
    ];
    
    return comparisons.filter(c => c.better).map(c => c.name);
}

/**
 * Find top metric gaps
 */
function findTopMetricGaps(winner, loser) {
    const gaps = [
        { name: 'Revenue per Hour', gap: ((winner.rph - loser.rph) / loser.rph) * 100 },
        { name: 'Revenue per Employee', gap: ((winner.rpe - loser.rpe) / loser.rpe) * 100 },
        { name: 'Profit per Hour', gap: ((winner.pph - loser.pph) / loser.pph) * 100 },
        { name: 'Profit per Employee', gap: ((winner.ppe - loser.ppe) / loser.ppe) * 100 }
    ];
    
    return gaps
        .filter(g => g.gap > 0)
        .sort((a, b) => b.gap - a.gap)
        .slice(0, 3);
}

/**
 * Generate actionable recommendations
 */
function generateRecommendations() {
    const container = document.getElementById('recommendationsContent');
    if (!container) return;
    
    const metricsA = AppState.resultsA;
    const metricsB = AppState.resultsB;
    const cpi = calculateCPI(metricsA, metricsB);
    
    const winner = cpi.winner === 'Tie' ? 'Both' : cpi.winner;
    const loser = cpi.winner === 'A' ? 'B' : (cpi.winner === 'B' ? 'A' : 'Both');
    const winnerMetrics = winner === 'A' ? metricsA : metricsB;
    const loserMetrics = loser === 'A' ? metricsA : metricsB;
    
    const recommendations = [];
    
    // 1. Throughput & Pricing
    recommendations.push(...generateThroughputRecommendations(winnerMetrics, loserMetrics, winner, loser));
    
    // 2. Process & Automation
    recommendations.push(...generateProcessRecommendations(winnerMetrics, loserMetrics, winner, loser));
    
    // 3. Talent & Incentives
    recommendations.push(...generateTalentRecommendations(winnerMetrics, loserMetrics, winner, loser));
    
    // 4. Cost Discipline
    recommendations.push(...generateCostRecommendations(winnerMetrics, loserMetrics, winner, loser));
    
    // 5. Product Strategy
    recommendations.push(...generateProductRecommendations(winnerMetrics, loserMetrics, winner, loser));
    
    // 6. Time Leverage
    recommendations.push(...generateTimeLeverageRecommendations(winnerMetrics, loserMetrics, winner, loser));
    
    // Sort by priority and impact
    recommendations.sort((a, b) => {
        const priorityOrder = { 'high': 0, 'medium': 1, 'low': 2 };
        return priorityOrder[a.priority] - priorityOrder[b.priority];
    });
    
    // Render recommendations
    container.innerHTML = recommendations.map((rec, i) => `
        <div class="recommendation-card bg-white dark:bg-gray-700 rounded-lg p-5 border-l-4 border-${rec.color}-500 shadow-sm hover:shadow-md transition-shadow">
            <div class="flex items-start gap-4">
                <div class="flex-shrink-0">
                    <div class="w-10 h-10 rounded-full bg-${rec.color}-100 dark:bg-${rec.color}-900/30 flex items-center justify-center">
                        <i class="fas ${rec.icon} text-${rec.color}-600 dark:text-${rec.color}-400"></i>
                    </div>
                </div>
                <div class="flex-1">
                    <div class="flex items-center gap-2 mb-2">
                        <span class="px-2 py-1 text-xs font-bold rounded ${rec.priority === 'high' ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300' : rec.priority === 'medium' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300' : 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300'}">
                            ${rec.priority.toUpperCase()}
                        </span>
                        <span class="text-xs text-gray-500 dark:text-gray-400">${rec.category}</span>
                    </div>
                    <h4 class="font-bold text-lg mb-2 text-gray-900 dark:text-gray-100">${rec.title}</h4>
                    <p class="text-gray-700 dark:text-gray-300 mb-3">${rec.description}</p>
                    <div class="flex items-center gap-4 text-sm">
                        <span class="text-green-600 dark:text-green-400 font-semibold">
                            <i class="fas fa-arrow-up mr-1"></i>Target: ${rec.impact}
                        </span>
                        <span class="text-gray-500 dark:text-gray-400">
                            <i class="fas fa-clock mr-1"></i>${rec.timeframe}
                        </span>
                        <span class="text-blue-600 dark:text-blue-400">
                            <i class="fas fa-bullseye mr-1"></i>${rec.metric}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

/**
 * Generate throughput recommendations
 */
function generateThroughputRecommendations(winnerMetrics, loserMetrics, winner, loser) {
    const recs = [];
    
    if (loser !== 'Both' && loserMetrics.rph < winnerMetrics.rph * 0.7) {
        recs.push({
            category: 'Throughput & Pricing',
            priority: 'high',
            title: 'Implement Dynamic Pricing & Yield Management',
            description: `Company ${loser}'s revenue per hour is ${((1 - loserMetrics.rph / winnerMetrics.rph) * 100).toFixed(0)}% lower than Company ${winner}. Adopt yield management strategies: test price elasticity, implement surge pricing for peak demand, and optimize your product/service mix toward higher-value offerings.`,
            impact: '+10-15% RPH, +5-8% PPH',
            timeframe: '60-90 days',
            metric: 'Revenue per Hour',
            icon: 'fa-dollar-sign',
            color: 'green'
        });
    }
    
    return recs;
}

/**
 * Generate process recommendations
 */
function generateProcessRecommendations(winnerMetrics, loserMetrics, winner, loser) {
    const recs = [];
    
    if (loser !== 'Both' && loserMetrics.laborIntensity > winnerMetrics.laborIntensity * 1.3) {
        recs.push({
            category: 'Process & Automation',
            priority: 'high',
            title: 'Automate High-Volume, Low-Value Tasks',
            description: `Company ${loser} employees work ${loserMetrics.laborIntensity.toFixed(0)} hours vs ${winnerMetrics.laborIntensity.toFixed(0)} hours per employee. Identify repetitive tasks (order processing, scheduling, reporting) and automate them. Use workflow automation tools and self-service portals to reduce manual labor.`,
            impact: '+15-25% time savings, +10-20% RPH',
            timeframe: '90-120 days',
            metric: 'Labor Hours',
            icon: 'fa-robot',
            color: 'blue'
        });
    }
    
    return recs;
}

/**
 * Generate talent recommendations
 */
function generateTalentRecommendations(winnerMetrics, loserMetrics, winner, loser) {
    const recs = [];
    
    if (loser !== 'Both' && loserMetrics.ppe < winnerMetrics.ppe * 0.6) {
        recs.push({
            category: 'Talent & Incentives',
            priority: 'medium',
            title: 'Align Incentives to PPH and PPE Improvements',
            description: `Company ${loser}'s profit per employee (${formatCurrency(loserMetrics.ppe, 0)}) trails significantly. Create performance incentives tied directly to productivity metrics: bonuses for PPH/PPE gains, profit-sharing based on margin improvements, and recognition for efficiency innovations.`,
            impact: '+8-12% PPE, +5-10% engagement',
            timeframe: '30-60 days',
            metric: 'Profit per Employee',
            icon: 'fa-trophy',
            color: 'purple'
        });
    }
    
    return recs;
}

/**
 * Generate cost recommendations
 */
function generateCostRecommendations(winnerMetrics, loserMetrics, winner, loser) {
    const recs = [];
    
    if (loser !== 'Both' && loserMetrics.profitMargin < winnerMetrics.profitMargin * 0.7) {
        recs.push({
            category: 'Cost Discipline',
            priority: 'high',
            title: 'COGS Renegotiation & Waste Reduction',
            description: `Company ${loser}'s profit margin (${formatPercent(loserMetrics.profitMargin)}) is significantly lower. Launch a comprehensive cost review: renegotiate supplier contracts, implement lean/waste reduction programs, consolidate vendors, and audit for shrinkage or inefficiency.`,
            impact: '+3-5% margin improvement',
            timeframe: '60-90 days',
            metric: 'Profit Margin',
            icon: 'fa-cut',
            color: 'red'
        });
    }
    
    return recs;
}

/**
 * Generate product recommendations
 */
function generateProductRecommendations(winnerMetrics, loserMetrics, winner, loser) {
    const recs = [];
    
    if (loserMetrics.profitMargin > 0 && loserMetrics.rph < winnerMetrics.rph) {
        recs.push({
            category: 'Product Strategy',
            priority: 'medium',
            title: 'Focus on High-PPH Product/Service Lines',
            description: `Conduct SKU-level or service-level profitability analysis. Identify which offerings deliver the highest profit per hour and profit per employee. Double down on these winners and prune or re-price underperformers. This drives mix optimization.`,
            impact: '+12-18% PPH through mix shift',
            timeframe: '90-120 days',
            metric: 'Product Mix',
            icon: 'fa-box-open',
            color: 'indigo'
        });
    }
    
    return recs;
}

/**
 * Generate time leverage recommendations
 */
function generateTimeLeverageRecommendations(winnerMetrics, loserMetrics, winner, loser) {
    const recs = [];
    
    recs.push({
        category: 'Time Leverage',
        priority: 'medium',
        title: 'Identify and Standardize "10× Impact" Decisions',
        description: `Map out decisions and processes that have disproportionate impact on revenue and profit. Standardize these through playbooks, templates, and decision frameworks. Delegate everything else. This multiplies the leverage of your best talent and creates compounding productivity gains.`,
        impact: '+20-30% leadership leverage',
        timeframe: '60-90 days',
        metric: 'Decision Quality',
        icon: 'fa-brain',
        color: 'teal'
    });
    
    return recs;
}
