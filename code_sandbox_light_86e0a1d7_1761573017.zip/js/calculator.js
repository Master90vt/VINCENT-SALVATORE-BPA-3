/**
 * Business Productivity Analyzer - Calculator Module
 * Handles all metric calculations including CPI
 */

/**
 * Calculate all productivity metrics for a company
 */
function calculateMetrics(data) {
    const metrics = {};
    
    // Basic inputs
    metrics.companyName = data.companyName || `Company ${data.company}`;
    metrics.revenue = data.revenue;
    metrics.profit = data.profit;
    metrics.employees = data.employees;
    metrics.hours = data.hours;
    metrics.period = data.period;
    metrics.periodFactor = data.periodFactor;
    metrics.cogs = data.cogs || 0;
    metrics.opex = data.opex || 0;
    metrics.notes = data.notes || '';
    
    // 1. Revenue per Employee (RPE)
    metrics.rpe = data.revenue / data.employees;
    
    // 2. Profit per Employee (PPE)
    metrics.ppe = data.profit / data.employees;
    
    // 3. Revenue per Labor Hour (RPH)
    metrics.rph = data.revenue / data.hours;
    
    // 4. Profit per Labor Hour (PPH)
    metrics.pph = data.profit / data.hours;
    
    // 5. Profit Margin
    metrics.profitMargin = data.revenue > 0 ? data.profit / data.revenue : 0;
    
    // 6. Gross Value Added (GVA) - if COGS provided
    if (data.cogs > 0) {
        metrics.gva = data.revenue - data.cogs;
        metrics.gvaPerEmployee = metrics.gva / data.employees;
        metrics.gvaPerHour = metrics.gva / data.hours;
    } else {
        metrics.gva = null;
        metrics.gvaPerEmployee = null;
        metrics.gvaPerHour = null;
    }
    
    // 7. Annualized metrics
    metrics.annualizedRPE = metrics.rpe * data.periodFactor;
    metrics.annualizedPPE = metrics.ppe * data.periodFactor;
    metrics.annualizedRPH = metrics.rph * data.periodFactor;
    metrics.annualizedPPH = metrics.pph * data.periodFactor;
    
    if (metrics.gva !== null) {
        metrics.annualizedGVA = metrics.gva * data.periodFactor;
        metrics.annualizedGVAPerEmployee = metrics.gvaPerEmployee * data.periodFactor;
        metrics.annualizedGVAPerHour = metrics.gvaPerHour * data.periodFactor;
    }
    
    // 8. Labor Intensity (hours per employee)
    metrics.laborIntensity = data.hours / data.employees;
    
    // 9. Output Elasticity Proxy
    metrics.outputElasticity = metrics.ppe !== 0 ? metrics.rph / metrics.ppe : 0;
    
    // 10. Warnings and flags
    metrics.warnings = [];
    
    if (metrics.profitMargin > 0.8) {
        metrics.warnings.push({ 
            type: 'high_margin', 
            message: 'Profit margin > 80% - unusually high',
            icon: 'fa-exclamation-triangle',
            color: 'text-yellow-500'
        });
    }
    
    if (metrics.profitMargin < 0) {
        metrics.warnings.push({ 
            type: 'negative_margin', 
            message: 'Negative profit margin - business is losing money',
            icon: 'fa-exclamation-circle',
            color: 'text-red-500'
        });
    }
    
    const maxHoursPerEmployee = {
        'week': 80,
        'month': 320,
        'quarter': 960,
        'half': 1920,
        'year': 3840
    };
    
    if (metrics.laborIntensity > maxHoursPerEmployee[data.period]) {
        metrics.warnings.push({ 
            type: 'high_hours', 
            message: `Hours per employee (${metrics.laborIntensity.toFixed(0)}) seems very high`,
            icon: 'fa-clock',
            color: 'text-orange-500'
        });
    }
    
    if (data.notes.toLowerCase().includes('seasonal')) {
        metrics.warnings.push({ 
            type: 'seasonal', 
            message: 'Seasonal business - results may vary by period',
            icon: 'fa-calendar',
            color: 'text-blue-500'
        });
    }
    
    if (data.notes.toLowerCase().includes('one-off') || data.notes.toLowerCase().includes('one off')) {
        metrics.warnings.push({ 
            type: 'oneoff', 
            message: 'One-off project noted - may not be sustainable',
            icon: 'fa-info-circle',
            color: 'text-purple-500'
        });
    }
    
    if (data.profit === 0) {
        metrics.warnings.push({ 
            type: 'no_profit', 
            message: 'Profit data not available or zero',
            icon: 'fa-question-circle',
            color: 'text-gray-500'
        });
    }
    
    return metrics;
}

/**
 * Calculate Composite Productivity Index (CPI)
 * Uses z-score normalization to combine different metrics
 */
function calculateCPI(metricsA, metricsB, weights = null) {
    if (!weights) {
        weights = AppState.cpiWeights;
    }
    
    // Components for CPI
    const components = ['rph', 'rpe', 'pph', 'ppe'];
    
    // Calculate z-scores for each component
    const zScores = {};
    
    components.forEach(component => {
        const valueA = metricsA[component];
        const valueB = metricsB[component];
        
        // Mean and standard deviation
        const mean = (valueA + valueB) / 2;
        const variance = (Math.pow(valueA - mean, 2) + Math.pow(valueB - mean, 2)) / 2;
        const stdDev = Math.sqrt(variance);
        
        // Calculate z-scores (handle zero stdDev case)
        if (stdDev === 0) {
            zScores[component] = { A: 0, B: 0 };
        } else {
            zScores[component] = {
                A: (valueA - mean) / stdDev,
                B: (valueB - mean) / stdDev
            };
        }
    });
    
    // Calculate weighted CPI
    let cpiA = 0;
    let cpiB = 0;
    
    components.forEach(component => {
        cpiA += zScores[component].A * weights[component];
        cpiB += zScores[component].B * weights[component];
    });
    
    // Normalize to 0-100 scale (shift and scale)
    const minCpi = Math.min(cpiA, cpiB);
    const maxCpi = Math.max(cpiA, cpiB);
    const range = maxCpi - minCpi;
    
    let normalizedA, normalizedB;
    
    if (range === 0) {
        normalizedA = normalizedB = 50; // Equal performance
    } else {
        normalizedA = ((cpiA - minCpi) / range) * 100;
        normalizedB = ((cpiB - minCpi) / range) * 100;
    }
    
    return {
        raw: { A: cpiA, B: cpiB },
        normalized: { A: normalizedA, B: normalizedB },
        zScores: zScores,
        components: components,
        weights: weights,
        winner: normalizedA > normalizedB ? 'A' : (normalizedB > normalizedA ? 'B' : 'Tie'),
        gap: Math.abs(normalizedA - normalizedB)
    };
}

/**
 * Update summary ribbon with key metrics
 */
function updateSummaryRibbon() {
    const cpi = calculateCPI(AppState.resultsA, AppState.resultsB);
    
    // Winner
    const winnerText = cpi.winner === 'Tie' ? 'Tie' : `Company ${cpi.winner}`;
    document.getElementById('ribbonWinner').textContent = winnerText;
    
    // CPI Gap
    document.getElementById('ribbonCpiGap').textContent = `${cpi.gap.toFixed(1)} points`;
    
    // Best metric
    const bestMetric = findBestMetric();
    document.getElementById('ribbonBestMetric').textContent = bestMetric;
    
    // Period
    const period = getPeriodLabel(AppState.companyA.period);
    document.getElementById('ribbonPeriod').textContent = period;
}

/**
 * Find the metric with the biggest difference
 */
function findBestMetric() {
    const metrics = ['rph', 'rpe', 'pph', 'ppe'];
    let maxDiff = 0;
    let bestMetric = '';
    
    metrics.forEach(metric => {
        const valueA = AppState.resultsA[metric];
        const valueB = AppState.resultsB[metric];
        const diff = Math.abs(valueA - valueB);
        const percentDiff = diff / Math.min(valueA, valueB);
        
        if (percentDiff > maxDiff) {
            maxDiff = percentDiff;
            bestMetric = metric.toUpperCase();
        }
    });
    
    return bestMetric || 'N/A';
}

/**
 * Generate weight control sliders
 */
function generateWeightControls() {
    const container = document.getElementById('weightControls');
    if (!container) return;
    
    container.innerHTML = '';
    
    const weights = [
        { key: 'rph', label: 'Revenue per Hour (RPH)', color: 'blue' },
        { key: 'rpe', label: 'Revenue per Employee (RPE)', color: 'green' },
        { key: 'pph', label: 'Profit per Hour (PPH)', color: 'purple' },
        { key: 'ppe', label: 'Profit per Employee (PPE)', color: 'orange' }
    ];
    
    weights.forEach(weight => {
        const currentValue = AppState.cpiWeights[weight.key];
        
        const controlHTML = `
            <div class="weight-control">
                <label class="block text-sm font-semibold mb-2">
                    <span class="inline-block w-3 h-3 rounded-full bg-${weight.color}-500 mr-2"></span>
                    ${weight.label}
                </label>
                <input 
                    type="range" 
                    id="weight_${weight.key}" 
                    min="0" 
                    max="1" 
                    step="0.05" 
                    value="${currentValue}"
                    class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                />
                <div class="flex justify-between mt-1 text-xs text-gray-600 dark:text-gray-400">
                    <span>0%</span>
                    <span id="weight_${weight.key}_value" class="font-bold text-${weight.color}-600 dark:text-${weight.color}-400">${(currentValue * 100).toFixed(0)}%</span>
                    <span>100%</span>
                </div>
            </div>
        `;
        
        const div = document.createElement('div');
        div.innerHTML = controlHTML;
        container.appendChild(div);
        
        // Add event listener
        const slider = document.getElementById(`weight_${weight.key}`);
        slider.addEventListener('input', (e) => {
            const newValue = parseFloat(e.target.value);
            AppState.cpiWeights[weight.key] = newValue;
            
            // Update display
            document.getElementById(`weight_${weight.key}_value`).textContent = `${(newValue * 100).toFixed(0)}%`;
            
            // Normalize weights to sum to 1
            normalizeWeights();
            
            // Recalculate and update UI
            updateAfterWeightChange();
        });
    });
}

/**
 * Normalize weights to sum to 1.0
 */
function normalizeWeights() {
    const sum = Object.values(AppState.cpiWeights).reduce((a, b) => a + b, 0);
    
    if (sum === 0) {
        // Reset to defaults if all zeros
        AppState.cpiWeights = { rph: 0.35, rpe: 0.25, pph: 0.25, ppe: 0.15 };
    } else if (sum !== 1.0) {
        // Normalize
        Object.keys(AppState.cpiWeights).forEach(key => {
            AppState.cpiWeights[key] = AppState.cpiWeights[key] / sum;
        });
    }
    
    // Update all weight displays
    Object.keys(AppState.cpiWeights).forEach(key => {
        const slider = document.getElementById(`weight_${key}`);
        const display = document.getElementById(`weight_${key}_value`);
        
        if (slider) slider.value = AppState.cpiWeights[key];
        if (display) display.textContent = `${(AppState.cpiWeights[key] * 100).toFixed(0)}%`;
    });
}

/**
 * Update UI after weight change
 */
function updateAfterWeightChange() {
    // Recalculate CPI
    const cpi = calculateCPI(AppState.resultsA, AppState.resultsB);
    
    // Update comparison cards
    generateComparisonCards();
    
    // Update charts
    renderCharts();
    
    // Update summary ribbon
    updateSummaryRibbon();
    
    // Check if winner changed
    const previousWinner = document.getElementById('ribbonWinner').textContent;
    const newWinner = cpi.winner === 'Tie' ? 'Tie' : `Company ${cpi.winner}`;
    
    if (previousWinner !== newWinner && previousWinner !== '-') {
        console.log(`⚠️ Winner changed: ${previousWinner} → ${newWinner}`);
    }
}

/**
 * Generate comparison cards
 */
function generateComparisonCards() {
    const container = document.getElementById('comparisonCards');
    if (!container) return;
    
    container.innerHTML = '';
    
    const cpi = calculateCPI(AppState.resultsA, AppState.resultsB);
    
    // Cards to display
    const cards = [
        {
            title: 'Composite Productivity Index',
            key: 'cpi',
            valueA: cpi.normalized.A,
            valueB: cpi.normalized.B,
            format: 'number',
            suffix: ' pts',
            icon: 'fa-trophy',
            color: 'purple',
            isHighlighted: true
        },
        {
            title: 'Revenue per Hour',
            key: 'rph',
            valueA: AppState.resultsA.rph,
            valueB: AppState.resultsB.rph,
            format: 'currency',
            suffix: '/hr',
            icon: 'fa-clock',
            color: 'blue'
        },
        {
            title: 'Profit per Hour',
            key: 'pph',
            valueA: AppState.resultsA.pph,
            valueB: AppState.resultsB.pph,
            format: 'currency',
            suffix: '/hr',
            icon: 'fa-dollar-sign',
            color: 'green'
        },
        {
            title: 'Revenue per Employee',
            key: 'rpe',
            valueA: AppState.resultsA.rpe,
            valueB: AppState.resultsB.rpe,
            format: 'currency',
            suffix: '',
            icon: 'fa-user',
            color: 'indigo'
        },
        {
            title: 'Profit per Employee',
            key: 'ppe',
            valueA: AppState.resultsA.ppe,
            valueB: AppState.resultsB.ppe,
            format: 'currency',
            suffix: '',
            icon: 'fa-users',
            color: 'teal'
        },
        {
            title: 'Profit Margin',
            key: 'profitMargin',
            valueA: AppState.resultsA.profitMargin,
            valueB: AppState.resultsB.profitMargin,
            format: 'percent',
            suffix: '',
            icon: 'fa-percentage',
            color: 'orange'
        }
    ];
    
    cards.forEach(card => {
        const winner = card.valueA > card.valueB ? 'A' : (card.valueB > card.valueA ? 'B' : 'Tie');
        const delta = ((card.valueB - card.valueA) / card.valueA) * 100;
        const absDelta = Math.abs(delta);
        
        let formattedA, formattedB;
        
        if (card.format === 'currency') {
            formattedA = formatCurrency(card.valueA, 2);
            formattedB = formatCurrency(card.valueB, 2);
        } else if (card.format === 'percent') {
            formattedA = formatPercent(card.valueA, 1);
            formattedB = formatPercent(card.valueB, 1);
        } else {
            formattedA = formatNumber(card.valueA, 1);
            formattedB = formatNumber(card.valueB, 1);
        }
        
        const cardHTML = `
            <div class="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 border-2 ${card.isHighlighted ? 'border-purple-500' : 'border-gray-200 dark:border-gray-700'} transition-all hover:shadow-xl">
                <div class="flex items-center justify-between mb-4">
                    <h4 class="text-lg font-bold text-gray-900 dark:text-gray-100">${card.title}</h4>
                    <div class="bg-${card.color}-100 dark:bg-${card.color}-900/30 p-2 rounded-lg">
                        <i class="fas ${card.icon} text-${card.color}-600 dark:text-${card.color}-400"></i>
                    </div>
                </div>
                
                <div class="space-y-3">
                    <div class="flex items-center justify-between">
                        <span class="text-sm font-medium text-gray-600 dark:text-gray-400">${AppState.resultsA.companyName}</span>
                        <span class="text-xl font-bold ${winner === 'A' ? 'text-green-600 dark:text-green-400' : 'text-gray-700 dark:text-gray-300'}">
                            ${formattedA}${card.suffix}
                            ${winner === 'A' ? '<i class="fas fa-crown text-yellow-500 ml-2"></i>' : ''}
                        </span>
                    </div>
                    
                    <div class="flex items-center justify-between">
                        <span class="text-sm font-medium text-gray-600 dark:text-gray-400">${AppState.resultsB.companyName}</span>
                        <span class="text-xl font-bold ${winner === 'B' ? 'text-green-600 dark:text-green-400' : 'text-gray-700 dark:text-gray-300'}">
                            ${formattedB}${card.suffix}
                            ${winner === 'B' ? '<i class="fas fa-crown text-yellow-500 ml-2"></i>' : ''}
                        </span>
                    </div>
                    
                    <div class="pt-3 border-t border-gray-200 dark:border-gray-700">
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-gray-600 dark:text-gray-400">Delta</span>
                            <span class="font-bold ${delta > 0 ? 'text-green-600' : delta < 0 ? 'text-red-600' : 'text-gray-600'}">
                                ${delta > 0 ? '↑' : delta < 0 ? '↓' : '='} ${absDelta.toFixed(1)}%
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        container.insertAdjacentHTML('beforeend', cardHTML);
    });
}
