/**
 * Business Productivity Analyzer - Charts Module
 * Handles all chart rendering with Chart.js
 */

/**
 * Render all charts
 */
function renderCharts() {
    renderBarChart();
    renderRadarChart();
    renderWaterfallCharts();
}

/**
 * Get chart colors based on theme
 */
function getChartColors() {
    const isDark = document.documentElement.classList.contains('dark');
    
    return {
        companyA: {
            background: 'rgba(59, 130, 246, 0.2)',
            border: 'rgb(59, 130, 246)',
            solid: 'rgb(59, 130, 246)'
        },
        companyB: {
            background: 'rgba(147, 51, 234, 0.2)',
            border: 'rgb(147, 51, 234)',
            solid: 'rgb(147, 51, 234)'
        },
        grid: isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)',
        text: isDark ? 'rgba(255, 255, 255, 0.8)' : 'rgba(0, 0, 0, 0.8)',
        positive: 'rgba(34, 197, 94, 0.8)',
        negative: 'rgba(239, 68, 68, 0.8)'
    };
}

/**
 * Get common chart options
 */
function getCommonChartOptions(title = '') {
    const colors = getChartColors();
    
    return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: false
            },
            legend: {
                display: true,
                position: 'top',
                labels: {
                    color: colors.text,
                    font: {
                        size: 12,
                        weight: '600'
                    },
                    padding: 15,
                    usePointStyle: true
                }
            },
            tooltip: {
                backgroundColor: 'rgba(0, 0, 0, 0.9)',
                titleColor: 'white',
                bodyColor: 'white',
                borderColor: colors.text,
                borderWidth: 1,
                padding: 12,
                displayColors: true,
                callbacks: {
                    label: function(context) {
                        let label = context.dataset.label || '';
                        if (label) {
                            label += ': ';
                        }
                        if (context.parsed.y !== null) {
                            label += formatCurrency(context.parsed.y, 2);
                        }
                        return label;
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: colors.grid
                },
                ticks: {
                    color: colors.text,
                    callback: function(value) {
                        return formatCurrency(value, 0);
                    }
                }
            },
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    color: colors.text,
                    font: {
                        size: 11
                    }
                }
            }
        }
    };
}

/**
 * Render bar chart comparing key metrics
 */
function renderBarChart() {
    const canvas = document.getElementById('barChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const colors = getChartColors();
    
    // Destroy existing chart
    if (AppState.charts.barChart) {
        AppState.charts.barChart.destroy();
    }
    
    const metricsA = AppState.resultsA;
    const metricsB = AppState.resultsB;
    
    const data = {
        labels: ['Revenue/Hour', 'Profit/Hour', 'Revenue/Employee', 'Profit/Employee'],
        datasets: [
            {
                label: metricsA.companyName,
                data: [metricsA.rph, metricsA.pph, metricsA.rpe, metricsA.ppe],
                backgroundColor: colors.companyA.background,
                borderColor: colors.companyA.border,
                borderWidth: 2
            },
            {
                label: metricsB.companyName,
                data: [metricsB.rph, metricsB.pph, metricsB.rpe, metricsB.ppe],
                backgroundColor: colors.companyB.background,
                borderColor: colors.companyB.border,
                borderWidth: 2
            }
        ]
    };
    
    const options = getCommonChartOptions();
    
    AppState.charts.barChart = new Chart(ctx, {
        type: 'bar',
        data: data,
        options: options
    });
}

/**
 * Render radar chart for CPI components
 */
function renderRadarChart() {
    const canvas = document.getElementById('radarChart');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const colors = getChartColors();
    
    // Destroy existing chart
    if (AppState.charts.radarChart) {
        AppState.charts.radarChart.destroy();
    }
    
    const metricsA = AppState.resultsA;
    const metricsB = AppState.resultsB;
    
    // Normalize values to 0-100 scale for better visualization
    const normalizeValue = (valueA, valueB) => {
        const max = Math.max(valueA, valueB);
        return {
            A: max > 0 ? (valueA / max) * 100 : 0,
            B: max > 0 ? (valueB / max) * 100 : 0
        };
    };
    
    const rph = normalizeValue(metricsA.rph, metricsB.rph);
    const rpe = normalizeValue(metricsA.rpe, metricsB.rpe);
    const pph = normalizeValue(metricsA.pph, metricsB.pph);
    const ppe = normalizeValue(metricsA.ppe, metricsB.ppe);
    
    const data = {
        labels: [
            `Revenue/Hour\n(Weight: ${(AppState.cpiWeights.rph * 100).toFixed(0)}%)`,
            `Revenue/Employee\n(Weight: ${(AppState.cpiWeights.rpe * 100).toFixed(0)}%)`,
            `Profit/Hour\n(Weight: ${(AppState.cpiWeights.pph * 100).toFixed(0)}%)`,
            `Profit/Employee\n(Weight: ${(AppState.cpiWeights.ppe * 100).toFixed(0)}%)`
        ],
        datasets: [
            {
                label: metricsA.companyName,
                data: [rph.A, rpe.A, pph.A, ppe.A],
                backgroundColor: colors.companyA.background,
                borderColor: colors.companyA.border,
                borderWidth: 2,
                pointBackgroundColor: colors.companyA.solid,
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: colors.companyA.border
            },
            {
                label: metricsB.companyName,
                data: [rph.B, rpe.B, pph.B, ppe.B],
                backgroundColor: colors.companyB.background,
                borderColor: colors.companyB.border,
                borderWidth: 2,
                pointBackgroundColor: colors.companyB.solid,
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: colors.companyB.border
            }
        ]
    };
    
    const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: true,
                position: 'top',
                labels: {
                    color: colors.text,
                    font: {
                        size: 12,
                        weight: '600'
                    },
                    padding: 15,
                    usePointStyle: true
                }
            },
            tooltip: {
                backgroundColor: 'rgba(0, 0, 0, 0.9)',
                titleColor: 'white',
                bodyColor: 'white',
                borderColor: colors.text,
                borderWidth: 1,
                padding: 12,
                callbacks: {
                    label: function(context) {
                        let label = context.dataset.label || '';
                        if (label) {
                            label += ': ';
                        }
                        label += context.parsed.r.toFixed(1) + '/100';
                        return label;
                    }
                }
            }
        },
        scales: {
            r: {
                beginAtZero: true,
                max: 100,
                ticks: {
                    stepSize: 20,
                    color: colors.text,
                    backdropColor: 'transparent'
                },
                grid: {
                    color: colors.grid
                },
                pointLabels: {
                    color: colors.text,
                    font: {
                        size: 10
                    }
                }
            }
        }
    };
    
    AppState.charts.radarChart = new Chart(ctx, {
        type: 'radar',
        data: data,
        options: options
    });
}

/**
 * Render waterfall charts (if COGS data available)
 */
function renderWaterfallCharts() {
    const metricsA = AppState.resultsA;
    const metricsB = AppState.resultsB;
    
    // Only show if COGS is provided for at least one company
    if (metricsA.cogs === 0 && metricsB.cogs === 0) {
        document.getElementById('waterfallContainer')?.classList.add('hidden');
        return;
    }
    
    document.getElementById('waterfallContainer')?.classList.remove('hidden');
    
    // Render waterfall for Company A
    if (metricsA.cogs > 0) {
        renderWaterfallChart('waterfallChartA', metricsA, 'Company A', 'companyA');
    }
    
    // Render waterfall for Company B
    if (metricsB.cogs > 0) {
        renderWaterfallChart('waterfallChartB', metricsB, 'Company B', 'companyB');
    }
}

/**
 * Render individual waterfall chart
 */
function renderWaterfallChart(canvasId, metrics, companyName, companyKey) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const colors = getChartColors();
    
    // Destroy existing chart
    if (AppState.charts[canvasId]) {
        AppState.charts[canvasId].destroy();
    }
    
    // Calculate waterfall steps
    const revenue = metrics.revenue;
    const cogs = metrics.cogs || 0;
    const gva = metrics.gva || (revenue - cogs);
    const opex = metrics.opex || 0;
    const profit = metrics.profit;
    
    // Create waterfall data
    const steps = [
        { label: 'Revenue', value: revenue, color: colors.positive },
        { label: 'COGS', value: -cogs, color: colors.negative },
        { label: 'GVA', value: gva, color: colors.positive },
        { label: 'OpEx', value: -opex, color: colors.negative },
        { label: 'Profit', value: profit, color: profit >= 0 ? colors.positive : colors.negative }
    ];
    
    // Calculate cumulative values for stacking
    let cumulative = 0;
    const chartData = steps.map(step => {
        const start = cumulative;
        cumulative += step.value;
        return {
            label: step.label,
            value: Math.abs(step.value),
            start: Math.min(start, cumulative),
            color: step.color
        };
    });
    
    const data = {
        labels: chartData.map(d => d.label),
        datasets: [{
            label: companyName,
            data: chartData.map(d => d.value),
            backgroundColor: chartData.map(d => d.color),
            borderColor: chartData.map(d => d.color),
            borderWidth: 2
        }]
    };
    
    const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            title: {
                display: true,
                text: `${companyName} - Profit Waterfall`,
                color: colors.text,
                font: {
                    size: 14,
                    weight: 'bold'
                }
            },
            legend: {
                display: false
            },
            tooltip: {
                backgroundColor: 'rgba(0, 0, 0, 0.9)',
                titleColor: 'white',
                bodyColor: 'white',
                borderColor: colors.text,
                borderWidth: 1,
                padding: 12,
                callbacks: {
                    label: function(context) {
                        const step = steps[context.dataIndex];
                        return `${step.label}: ${formatCurrency(Math.abs(step.value), 0)}`;
                    }
                }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: {
                    color: colors.grid
                },
                ticks: {
                    color: colors.text,
                    callback: function(value) {
                        return formatCurrency(value, 0);
                    }
                }
            },
            x: {
                grid: {
                    display: false
                },
                ticks: {
                    color: colors.text,
                    font: {
                        size: 11
                    }
                }
            }
        }
    };
    
    AppState.charts[canvasId] = new Chart(ctx, {
        type: 'bar',
        data: data,
        options: options
    });
}

/**
 * Destroy all charts (for cleanup)
 */
function destroyAllCharts() {
    Object.keys(AppState.charts).forEach(key => {
        if (AppState.charts[key]) {
            AppState.charts[key].destroy();
            delete AppState.charts[key];
        }
    });
}
