# 📋 Business Productivity Analyzer - Example Scenarios

This document provides real-world example scenarios you can use to test and understand the Business Productivity Analyzer.

---

## 🏪 Scenario 1: Traditional Retail vs E-commerce

### **Company A: Traditional Brick & Mortar Store**
```
Revenue: $500,000
Profit: $50,000
Employees: 25
Hours: 4,000
Period: 1 Month
COGS: $300,000
OpEx: $150,000
Notes: Seasonal business, peak during holidays
```

**Expected Results:**
- RPH: $125/hr
- RPE: $20,000/employee
- PPH: $12.50/hr
- Profit Margin: 10%
- Labor Intensity: 160 hrs/employee

### **Company B: E-commerce Store**
```
Revenue: $600,000
Profit: $120,000
Employees: 8
Hours: 1,280
Period: 1 Month
COGS: $300,000
OpEx: $180,000
Notes: Automated fulfillment, low overhead
```

**Expected Results:**
- RPH: $468.75/hr (3.75× better!)
- RPE: $75,000/employee (3.75× better!)
- PPH: $93.75/hr (7.5× better!)
- Profit Margin: 20% (2× better!)
- Labor Intensity: 160 hrs/employee

**Winner:** Company B by a significant margin due to automation and lower overhead.

**Key Insight:** E-commerce model demonstrates superior time leverage and capital efficiency.

---

## 💼 Scenario 2: Agency vs Freelancer

### **Company A: Marketing Agency**
```
Revenue: $150,000
Profit: $30,000
Employees: 12
Hours: 2,000
Period: 1 Month
COGS: $50,000
OpEx: $70,000
Notes: Full-service agency with overhead
```

**Expected Results:**
- RPH: $75/hr
- RPE: $12,500/employee
- PPH: $15/hr
- Profit Margin: 20%

### **Company B: Solo Freelancer**
```
Revenue: $15,000
Profit: $10,000
Employees: 1
Hours: 120
Period: 1 Month
COGS: $2,000
OpEx: $3,000
Notes: Specialized consultant, premium pricing
```

**Expected Results:**
- RPH: $125/hr (1.67× better)
- RPE: $15,000/employee (1.2× better)
- PPH: $83.33/hr (5.55× better!)
- Profit Margin: 66.7% (3.3× better!)

**Winner:** Freelancer wins on per-hour profitability and margin, but agency has higher absolute revenue.

**Key Insight:** Solo model offers better unit economics but agency has more scalability potential.

---

## 🏭 Scenario 3: Manufacturing Efficiency Comparison

### **Company A: Traditional Manufacturing**
```
Revenue: $2,000,000
Profit: $200,000
Employees: 100
Hours: 16,000
Period: 1 Month
COGS: $1,200,000
OpEx: $600,000
Notes: Labor-intensive process
```

**Expected Results:**
- RPH: $125/hr
- RPE: $20,000/employee
- PPH: $12.50/hr
- Profit Margin: 10%
- Labor Intensity: 160 hrs/employee

### **Company B: Automated Manufacturing**
```
Revenue: $2,500,000
Profit: $500,000
Employees: 40
Hours: 6,400
Period: 1 Month
COGS: $1,200,000
OpEx: $800,000
Notes: High automation, capital-intensive
```

**Expected Results:**
- RPH: $390.63/hr (3.13× better!)
- RPE: $62,500/employee (3.13× better!)
- PPH: $78.13/hr (6.25× better!)
- Profit Margin: 20% (2× better!)
- Labor Intensity: 160 hrs/employee

**Winner:** Automated manufacturing dominates on all efficiency metrics.

**Key Insight:** Initial capital investment in automation pays off in superior productivity.

---

## 🍕 Scenario 4: Restaurant Comparison

### **Company A: Fast Food Chain Location**
```
Revenue: $80,000
Profit: $8,000
Employees: 15
Hours: 2,400
Period: 1 Month
COGS: $32,000
OpEx: $40,000
Notes: High volume, low margin
```

**Expected Results:**
- RPH: $33.33/hr
- RPE: $5,333/employee
- PPH: $3.33/hr
- Profit Margin: 10%
- GVA: $48,000

### **Company B: Fine Dining Restaurant**
```
Revenue: $120,000
Profit: $36,000
Employees: 12
Hours: 2,000
Period: 1 Month
COGS: $36,000
OpEx: $48,000
Notes: Premium pricing, lower volume
```

**Expected Results:**
- RPH: $60/hr (1.8× better)
- RPE: $10,000/employee (1.88× better)
- PPH: $18/hr (5.4× better!)
- Profit Margin: 30% (3× better!)
- GVA: $84,000

**Winner:** Fine dining wins on profitability and efficiency despite lower volume.

**Key Insight:** Premium positioning enables better margins and productivity per hour worked.

---

## 💻 Scenario 5: SaaS Companies - Early Stage vs Scale

### **Company A: Early-Stage SaaS Startup**
```
Revenue: $50,000
Profit: -$20,000
Employees: 8
Hours: 1,280
Period: 1 Month
COGS: $10,000
OpEx: $60,000
Notes: Growth mode, burning cash
```

**Expected Results:**
- RPH: $39.06/hr
- RPE: $6,250/employee
- PPH: -$15.63/hr (negative!)
- Profit Margin: -40% (losing money)
- ⚠️ Warning: Negative margin

### **Company B: Scaled SaaS Company**
```
Revenue: $1,000,000
Profit: $400,000
Employees: 20
Hours: 3,200
Period: 1 Month
COGS: $100,000
OpEx: $500,000
Notes: Profitable, efficient operations
```

**Expected Results:**
- RPH: $312.50/hr (8× better!)
- RPE: $50,000/employee (8× better!)
- PPH: $125/hr (positive vs negative!)
- Profit Margin: 40%
- GVA: $900,000

**Winner:** Scaled SaaS company demonstrates the power of software economics at scale.

**Key Insight:** SaaS model requires initial investment but delivers exceptional productivity at scale.

---

## 🏗️ Scenario 6: Construction Companies

### **Company A: General Contractor**
```
Revenue: $500,000
Profit: $75,000
Employees: 30
Hours: 5,000
Period: 1 Month
COGS: $300,000
OpEx: $125,000
Notes: Equipment intensive, project-based
```

**Expected Results:**
- RPH: $100/hr
- RPE: $16,667/employee
- PPH: $15/hr
- Profit Margin: 15%

### **Company B: Specialized Subcontractor**
```
Revenue: $200,000
Profit: $60,000
Employees: 8
Hours: 1,200
Period: 1 Month
COGS: $80,000
OpEx: $60,000
Notes: High-skill electrical work
```

**Expected Results:**
- RPH: $166.67/hr (1.67× better)
- RPE: $25,000/employee (1.5× better)
- PPH: $50/hr (3.33× better!)
- Profit Margin: 30% (2× better!)

**Winner:** Specialized subcontractor achieves better efficiency through focused expertise.

**Key Insight:** Specialization enables premium pricing and better productivity.

---

## 🎯 Scenario 7: Consulting Firms

### **Company A: Large Consulting Firm (Billable Hours Model)**
```
Revenue: $300,000
Profit: $90,000
Employees: 20
Hours: 2,800
Period: 1 Month
COGS: $0
OpEx: $210,000
Notes: Junior and senior consultants, high overhead
```

**Expected Results:**
- RPH: $107.14/hr
- RPE: $15,000/employee
- PPH: $32.14/hr
- Profit Margin: 30%

### **Company B: Boutique Strategy Consultancy (Value-Based Pricing)**
```
Revenue: $250,000
Profit: $150,000
Employees: 3
Hours: 360
Period: 1 Month
COGS: $0
OpEx: $100,000
Notes: Senior-only, high-value projects
```

**Expected Results:**
- RPH: $694.44/hr (6.48× better!)
- RPE: $83,333/employee (5.56× better!)
- PPH: $416.67/hr (13× better!)
- Profit Margin: 60% (2× better!)
- Labor Intensity: 120 hrs/employee

**Winner:** Boutique firm dramatically outperforms on all metrics.

**Key Insight:** Value-based pricing and senior-only model creates exceptional productivity.

---

## 🧪 Test Cases for Edge Cases

### **Edge Case 1: Zero Profit**
```
Revenue: $100,000
Profit: $0
Employees: 10
Hours: 1,600
Period: 1 Month
Notes: Break-even scenario
```
**Expected:** PPH and PPE = 0, profit metrics grayed out, warning shown.

### **Edge Case 2: Very High Margin (80%+)**
```
Revenue: $100,000
Profit: $90,000
Employees: 2
Hours: 100
Period: 1 Month
Notes: Software licensing, near-zero costs
```
**Expected:** ⚠️ Warning about unusually high margin (80%+)

### **Edge Case 3: Extreme Hours per Employee**
```
Revenue: $50,000
Profit: $10,000
Employees: 1
Hours: 720
Period: 1 Week
Notes: Crunch time, unsustainable
```
**Expected:** ⚠️ Warning about high hours (720 hrs/week = 103 hrs/day!)

### **Edge Case 4: Seasonal Business**
```
Revenue: $200,000
Profit: $40,000
Employees: 10
Hours: 1,600
Period: 1 Month
Notes: Seasonal, December holiday rush
```
**Expected:** ⚠️ Seasonal flag shown, insights note variability

### **Edge Case 5: Negative Profit**
```
Revenue: $100,000
Profit: -$20,000
Employees: 10
Hours: 1,600
Period: 1 Month
Notes: Loss-making period
```
**Expected:** ⚠️ Negative margin warning, recommendations focus on cost reduction

---

## 🎓 Learning Scenarios

### **Scenario: High Throughput vs High Margin**

**Company A: High Throughput, Low Margin (Volume Play)**
```
Revenue: $1,000,000
Profit: $100,000
Employees: 50
Hours: 8,000
Period: 1 Month
Notes: Walmart model - high volume, thin margins
```
- RPH: $125/hr
- Margin: 10%

**Company B: Low Throughput, High Margin (Premium Play)**
```
Revenue: $200,000
Profit: $100,000
Employees: 5
Hours: 1,000
Period: 1 Month
Notes: Luxury goods - low volume, premium pricing
```
- RPH: $200/hr
- Margin: 50%

**Teaching Point:** Both can be successful, but require different strategies. Company A needs operational excellence and scale. Company B needs brand power and exclusivity.

---

## 💡 How to Use These Scenarios

1. **Click "Load Example"** in the app
2. **Manually input** any of these scenarios
3. **Adjust CPI weights** to explore different perspectives
4. **Compare results** to understand different business models
5. **Review insights** to learn productivity principles
6. **Study recommendations** to understand improvement strategies

---

## 🎯 Challenge: Create Your Own Scenarios

Try these exercises:
1. **Your Current Business** - Input your real data and analyze
2. **Competitor Analysis** - Compare yourself to a competitor
3. **Goal Scenario** - Input your target metrics for next year
4. **Before/After** - Model the impact of a process improvement
5. **Build vs Buy** - Compare in-house vs outsourced options

---

**Happy Analyzing! 📊**
